<?php if(!class_exists('raintpl')){exit;}?><!-- Master JS Files -->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="http://cdn.jquerytools.org/1.2.7/full/jquery.tools.min.js"></script>
<script type="text/javascript" src="js/modernizr-2.0.6-development-only.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

<!-- Every Page -->
<script type="text/javascript" src="js/jquery.address-1.5.min.js"></script> <!-- Links -->
<script type="text/javascript" src="js/jquery.lightbox_me.js"></script> <!-- Lightbox -->
<script type="text/javascript" src="js/jquery.typeahead.js"></script> <!-- Menu Typeahead -->
<script type="text/javascript" src="js/jquery.collapse.js"></script> <!-- jQuery Collapse -->
<script type="text/javascript" src="js/jquery.collapse_storage.js"></script> <!-- jQuery Collapse Storage -->
<script type="text/javascript" src="js/jquery.menufication.min.js"></script> <!-- Menufication -->

<!-- This Page -->
<script type="text/javascript" src="js/jquery.isotope.js"></script> <!-- News -->
<script type="text/javascript" src="js/jquery.iosslider.min.js"></script> <!-- Slider -->
<script type="text/javascript" src="js/jquery.mousewheel.js"></script> <!-- Coverflow -->
<script type="text/javascript" src="js/raphael.min.js"></script> <!-- Coverflow -->
<script type="text/javascript" src="js/icarousel.js"></script> <!-- Coverflow -->
<script type="text/javascript" src="media/js/jquery.social.stream.wall.1.3.js"></script> <!-- Media Wall -->
<script type="text/javascript" src="media/js/jquery.social.stream.1.5.1.js"></script> <!-- Media Wall -->

<!-- SU Scripts-->
<script type="text/javascript" src="js/su-data-2.0.js"></script> <!-- SU DATA -->
<script type="text/javascript" src="js/su-widgets.js"></script> <!-- Widget Builder -->
<script type="text/javascript" src="js/su-frontpage.js"></script> <!-- Frontpage Scripts -->
<script type="text/javascript" src="js/su-menu.js"></script> <!-- Menu -->
<script type="text/javascript" src="js/su-common.js"></script>

<style>
.border { border: 1px solid #000; }
</style>

<!-- Important: SU_Data must be loaded before any other JS which uses Widget Data -->
