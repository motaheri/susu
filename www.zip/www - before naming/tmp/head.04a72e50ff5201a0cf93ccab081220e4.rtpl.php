<?php if(!class_exists('raintpl')){exit;}?>
        <!--[if lt IE 9]><script src="http://cdn.jsdelivr.net/html5shiv/3.6.1/html5shiv.min.js"></script><![endif]-->
		
        <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/normalize/2.0.1/normalize.css" />
		
		<link rel="stylesheet" type="text/css" href="media/css/dcsns_light.css" media="all" />
        <link rel="stylesheet" href="css/menufication.min.css" />
        <link rel="stylesheet" href="css/su-fonts.css" />
        <link rel="stylesheet" href="css/su-layout.css" />
        <link rel="stylesheet" href="css/su-news.css" />
        <link rel="stylesheet" href="css/su-events.css" />
        <link rel="stylesheet" href="css/su-blogs.css" />
        <link rel="stylesheet" href="css/su-lightbox.css" />
        <link rel="stylesheet" href="css/su-coverflow.css" />
        <link rel="stylesheet" href="css/su-menu.css" />
        <link rel="stylesheet" href="css/su-activities.css" />
        <link rel="stylesheet" href="css/su-media.css" />
        <link rel="stylesheet" href="css/su-union.css" />
		<link rel="stylesheet" href="css/su-advert.css" />
		<link rel="stylesheet" href="css/su-footer.css" />
		
        <link href="http://fonts.googleapis.com/css?family=Mako" rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Cantarell:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
        <!-- <link href='http://fonts.googleapis.com/css?family=Bitter:400,700,400italic' rel='stylesheet' type='text/css'> -->
		<!--[if gte IE 9]>
			<style type="text/css">
					hr.soft {
							filter: none;
					}
			</style>
		<![endif]-->
