<?php if(!class_exists('raintpl')){exit;}?><style>

#ss-box{
padding-left:20px;
} 
</style>

<h2>Your Societies</h2>
	
	
  