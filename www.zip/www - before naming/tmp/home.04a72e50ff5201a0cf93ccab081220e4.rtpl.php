<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<html>
    <head>
        <title>Swansea Student Events</title>
        
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "meta" );?>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "head" );?>
		
    </head>
    <body>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "menu" );?>
		
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "coverflow" );?>
		
		
		<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "advert" );?>
		
		<hr class="soft"/>
		
        <div id="main" class="clearfix">
			
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "news" );?>
			
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "events" );?>

			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "blogs" );?>
			
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "media" );?>

		</div>
		<hr class="soft"/>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "footer" );?>
		
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "scripts-index" );?>
		<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "scripts-facebook" );?>
		
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "widgetdata" );?>
    </body>
</html>
