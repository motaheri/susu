<?php if(!class_exists('raintpl')){exit;}?><div class="advert-container">
	<div class="wrapper">
		<div id="advert">
			<div class="fulladvert">
			<MSL:Advert DisplayLocation="SUFullBannerLeft" ContainerTag="" ContainerID="" ContainerCssClass="" SuppressContainer="True" />
			</div>
			<div class="halfadvert">
			<MSL:Advert DisplayLocation="SUHalfBannerCenter" ContainerTag="" ContainerID="" ContainerCssClass="" SuppressContainer="True" />
			</div>
			<div class="halfadvert">
			<MSL:Advert DisplayLocation="SUHalfBannerRight" ContainerTag="" ContainerID="" ContainerCssClass="" SuppressContainer="True" />
			</div>
			<div class="advertteaser">Advertisement Space</div>
		</div>
	</div>
</div>