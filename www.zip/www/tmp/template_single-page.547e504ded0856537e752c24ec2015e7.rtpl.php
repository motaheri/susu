<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html>
    <head>
        <title>Swansea University Students' Union</title>
        
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_meta" );?>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_head" );?>
		<link rel="stylesheet" href="css/su_template_single.css" />

    </head>
    <body>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_menu" );?>
		<div id="cover"></div>
        <div class="wrapper clearfix">
			<div id="aside">
				<aside>
					<div id="page-badge">
						<div id="page-badge-title">
							<h2>Officer Blogs</h2>
						</div>
						<div id="page-badge-photo">
							<img src="http://placehold.it/342x484" />
						</div>
					</div>
					<ul class="nav nav-list">
						<li class="nav-header">List header</li>
						<li class="active"><a href="#">Home</a></li>
						<li><a href="#">Library</a></li>
					</ul>
				</aside>
			</div>
			<div id="article">
				<article>
					<ul class="breadcrumb">
						<li><a href="#">News</a></li>
						<li class="active"><a href="#">Test 1</a></li>
						<li class="active"><a href="#">Test 2</a></li>
						<li class="active"><a href="#">Celebrate International Women's Day</a></li>
					</ul>
					<h2 class="title">Celebrate International Women's Day</h2>
					<p class="info">Posted by <span class="highlight">Swansea University Students' Union</span> on <span class="highlight">Thursday, 4th April 2013</span>.</p>
					<div class="content">
						<p>International Women's Day Events</p><p> Tuesday 5<sup>th</sup> March</p><p> On Tuesday we will be showing ?Pray the Devil Back to Hell' at Flux ?3 entry fee, in Divas to raise money for ?Women for Women'. Women for Women is a charity that help and aid socially excluded women from war and conflict torn countries, the film is about a band of Liberian women who banded together to fight for peace in their country, by staging a silent protest. It is a moving and empowering film that captures a group of strong empowered women bringing peace to a country at war with itself. <strong>Everyone is welcome</strong></p><p> Thursday 7<sup>th</sup> March</p><p> In the morning 11 am ? 1 pm MEWN will be holding a CV and employability drop in workshop with a presentation. Also, there will be a talk from Dr. Jan West, a science lecturer at Surrey University and part of the Daphne Jackson Trust. This talk will be on ?personal branding in the work place'. To sign up for this talk please email: <a href="mailto:womensofficer" swansea-union.co.uk@="">womensofficer@swansea-union.co.uk</a> [<strong>Limited Space Available</strong>]</p><p> Thursday afternoon Swansea Women's Centre will be coming back to Swansea University to host talks, information stalls, zines, crafts and much more! The Women's Center will be in Dining Room A from 10 am ? 3 pm <strong>Women Only, Free Event</strong></p><p> Friday 8<sup>th</sup> March - <strong>International Women's Day</strong></p><p> NUS are holding a Reclaim the Night Wales march in Cardiff. The event will start at 6 pm in Cardiff's Students' Union, they will then march the streets of Cardiff led by a block of self-defining women, then followed by activists of any gender behind. To find out more about the march please see the link below or click here.</p><p> Sunday 10<sup>th</sup> March ? <strong>Mothering Sunday</strong></p><p> MEWN are holding an International Women's Day event in Guild Hall. There will be talks, information and performances from self defining women. For more information please see their website.</p><p> Useful Links:</p><p> http://www.womenforwomen.org/<br> <a href="http://praythedevilbacktohell.com/synopsis.php">http://praythedevilbacktohell.com/synopsis.php</a><br> http://swanseawomenscentre.co.uk/<br> http://www.nusconnect.org.uk/ents/event/711/<br> http://www.mewnswansea.org.uk/<br>  </p>
					</div>
				</article>
			</div>
        </div>
		

        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_footer" );?>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_scripts-single" );?>
		<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_scripts-facebook" );?>

    </body>
</html>
