<?php if(!class_exists('raintpl')){exit;}?><div class="events-container">
	<div class="wrapper">
		<div id="events">
			<div id="su-eventsPortraitFilter" class="sliderFilter">
			</div>
			<h2><img class="headericon ticket-icon" src="img/ticket-icon.png"/> Events</h2>
			<div id="su-eventsPortrait">
			</div>
		</div>
		<div id="my-events">
			<div id="su-eventsLandscapeFilter" class="sliderFilter">
			</div>
			<h2><img class="headericon ticket-icon" src="img/ticket-icon.png"/> My Events
			<small class="su-eventsSubTitle">Events for your societies and sports clubs.</small>
			</h2>
			
			<div id="su-eventsLandscape">
			</div>
		</div>
		<div class="seemore">
			<a href="/events">More Events...</a>
		</div>
		<div id="events-lightbox" class="sulb">
			<div class="sulb-inner event">
				<div class="title"></div>
				<div class="clearfix"></div>
				<div class="buy">
					<h3>Tickets</h3>
					<div class="buy-info">
						<div>
							<select>
								<option>Standard (3.00)</option>
								<option>Queue Jump (5.00)</option>
							</select>
						</div>
						<div>
							Qty
							<select>
								<option>1</option>
								<option>2</option>
							</select>
						</div>
					</div>
					<button class="btn btn-large btn-success">Buy Tickets</button>
				</div>
				<img class="poster img-polaroid" src="img/event-a4-2.jpg" />
				<div class="desc">
					<p class="info"></p>
				</div>
				<h2 class="whiteToGray" id="sulb-eventgallery-title">Gallery</h2>
				<div class="sliderPhotoGallery">
					<!-- slider -->
					<div class="slider">
						<!-- slides -->
					</div>
				</div>
				<h2 class="grayToWhite" id="sulb-eventrelated-title">Related Events</h2>
				<div class="sulb-relatedEvents">
				</div>
			</div>
			<div class="sulb-author">Student Swansea Events</div>
		</div>
	</div>
</div>