<?php if(!class_exists('raintpl')){exit;}?><header class="clearfix header">
	<div id="menu" class="wrapper">
		<div id="menu-container">
			<div id="menu-left" class="no-mobile">
				<ul>
					<li id="menu-logo">
							<div id="logo-box" class="inline-box">
								<a href="/">
									<span class="suicon">
										<img src="http://www.swansea-union.co.uk/stylesheet/su/su_43px.gif" />
									</span>
									<div class="suicontext">
										<span>Swansea University</span> <span>Students' Union</span>
									</div>
								</a>
							</div>
					</li>
					
					<li id="search-box" class="inline-box">
							<span class="stts">Type to Search <img class="search-icon" src="http://www.swansea-union.co.uk/stylesheet/su/search.png" /></span>
							<input id="ss-input" name="ss-input" type="text" />
					</li>
				</ul>
			</div>
			<div id="menu-right" class="menu-block no-mobile">
				<ul class="menu-offleft menu-group">
					<li><a href="">Login</a></li>
					<li><a href=""><img src="http://www.swansea-union.co.uk/stylesheet/su/basket.png" class="menu-icon"/>Basket</a></li>
				</ul>
				<ul class="menu-far-right menu-group">
					<li><a href="">Union</a></li>
					<li><a href="./societies.php" rel="page">Societies</a></li>
					<li><a href="./sports.php" rel="page">Sports</a></li>
					<li><a href="./events.php" rel="page">Events</a></li>
				</ul>
			</div>
			<div id="menu-content-container">
				<div class="menu-content union">
					<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_menu-union" );?>
				</div>
				<div class="menu-content societies">	
				</div>
				<div class="menu-content sports">
				</div>
				<div class="menu-content events">
				</div>  
				<div class="menu-content login">
					<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_login" );?>
				</div>
				<div class="menu-content basket">
					 
				</div>
			</div>
		</div>
	</div>			
	<hr class="menu-line soft"/>	
</header>

<div id="menu-spacer"></div>

<!-- MOBILE MENU - Visible below 684px -->
<div id="su-mobile-menu" style="display: none;">
	<ul>
		<li>
			<a href="index.php">Union</a>
			<ul class="su-mobile-menu-sub">
				<li><a href="index.php">Democracy</a></li>
				<li><a href="index.php">Support</a></li>
				<li><a href="index.php">Shops</a></li>
				<li><a href="index.php">Venues</a></li>
			</ul>
		</li>
		<li>
			<a href="index.php">Societies</a>
		</li>
		<li>
			<a href="index.php">Sports</a>
		</li>
		<li>
			<a href="events.php">Events</a>
		</li>
	</ul>
</div>
<!-- MOBILE MENU - Visible below 684px -->
