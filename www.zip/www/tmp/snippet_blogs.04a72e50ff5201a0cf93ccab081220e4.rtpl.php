<?php if(!class_exists('raintpl')){exit;}?><div class="blog-container">
	<div class="wrapper">
	<h2><img class="headericon blog-icon" src="img/blogs-icon.png"/> Officer Blogs</h2>
	<div id="officer-blogs" class="su-blog"></div>
	<div class="seemore">
		More Blogs...
	</div>
	<div id="blog-lightbox" class="sulb">
		<div class="sulb-inner blog">
			<h2 class="title"></h2>
			<img class="lead img-polaroid" />
			<p class="info">Blogged by <span class="highlight organisation">Swansea University Students' Union</span> on <span class="highlight date"></span>.</p>
			<div class="desc"></div>
		</div>
		<div class="sulb-author"></div>
	</div>
	</div>
</div>