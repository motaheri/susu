<?php if(!class_exists('raintpl')){exit;}?>			<div class="events-container">
				<div class="wrapper">
					<div id="events">
						<div id="su-eventsPortraitFilter" class="sliderFilter">
						</div>
						<h2><img class="headericon ticket-icon" src="img/ticket-icon.png"/> Events</h2>
						<div id="su-eventsPortrait">
						</div>
					</div>
					<div id="my-events">
						<div id="su-eventsLandscapeFilter" class="sliderFilter">
						</div>
						<h2><img class="headericon ticket-icon" src="img/ticket-icon.png"/> My Events
						<small class="su-eventsSubTitle">Events for your societies and sports clubs.</small>
						</h2>
						
						<div id="su-eventsLandscape">
						</div>
					</div>
					<!--[if gte IE 9]>
					<style type="text/css">
						.sliderPortrait:before, .sliderSmall:before {
							filter: none;
						}
					</style>
					<![endif]-->
                    <div class="seemore">
                        <a href="/events.php">More Events...</a>
                    </div>
					<div id="events-lightbox" class="sulb">
						<div class="sulb-inner event">
							<div class="title">Event Title</div>
							<div class="clearfix"></div>
							<div class="buy">
								<h3>Tickets</h3>
								<div class="buy-info">
									<div>
										<select>
											<option>Standard (3.00)</option>
											<option>Queue Jump (5.00)</option>
										</select>
									</div>
									<div>
										Qty
										<select>
											<option>1</option>
											<option>2</option>
										</select>
									</div>
								</div>
								<button class="btn btn-large btn-success">Buy Tickets</button>
							</div>
							<img class="poster img-polaroid" src="img/event-a4-2.jpg" />
							<div class="desc">
								<p class="info">Sin City - 28th February 2013 @ 10pm</p>
								<p><b>Thursdays mean only one thing - Sin Savers!</b></p>
								<p>A favoured night for one and all at Swansea University. Sin Savers provides the perfect night out on a budget, with drinks so cheap, we're not even allowed to advertise them to you! Once you're in, you're part of the Sin Savers massive - an ecclectic bunch joined together for one night a week with one key similarity - The need to party!</p>
								<p>DJ Daz hosts with his unique set of 'Anything &amp; Everything goes', whether its dubstep, chart, 80's or Disney - You will hear it at Sin Savers! Every week differs, but the incredible atmosphere and of course the sticky floor will always remain.</p>
								<p>The cheapest night of the week, Sin Savers satisfies your every need for a night out and you'll have money for a kebab on the way home! No matter who you are, Sin Savers has something for you!</p>
							</div>
							<h2 class="whiteToGray" id="sulb-eventgallery-title">Gallery</h2>
							<div class="sliderPhotoGallery">
								<!-- slider -->
								<div class="slider">
									<!-- slides -->
								</div>
							</div>
							<h2 class="grayToWhite" id="sulb-eventrelated-title">Related Events</h2>
							<div class="sulb-relatedEvents">
							</div>
						</div>
						<div class="sulb-author">Student Swansea Events</div>
					</div>
				</div>
			</div>