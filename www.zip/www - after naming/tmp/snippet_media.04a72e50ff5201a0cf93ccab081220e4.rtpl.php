<?php if(!class_exists('raintpl')){exit;}?>			<div class="media-container">
				<div class="wrapper">
				<h2><img class="headericon media-icon" src="img/media-icon.png"/> Social Media</h2>
				
					<div id="su-media-frontpage"></div>
					
					<div class="seemore">
						More Social Media...
					</div>
				
				</div>
			</div>