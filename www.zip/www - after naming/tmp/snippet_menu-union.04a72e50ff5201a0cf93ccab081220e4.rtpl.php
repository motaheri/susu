<?php if(!class_exists('raintpl')){exit;}?>			<div id="menu-items">    
				<div class="democracy menu-list"><h1>Democracy</h1><div id="democracy-menu-id" class="mslwidget democracy-menu-css msl-imagenav">
				<ul><li><a href="/democracy/officers/">
						<span class="msl-imagenav-title">Officers</span>
						<img id="ctl00_democracymenu_rptNavigation_ctl01_imgPlaceholder" class="msl-imagenav-image" src="../pageassets/democracy/officers/325x229.gif?thumbnail=true&amp;height=229&amp;width=325&amp;resize_type=CropToFit" style="border-width:0px;">
						<span class="msl-imagenav-description">Your Elected Officers|Telephone:1233432|Contact:info@swansea-union.co.uk|Opening Times:</span>
						</a></li><li><a href="/democracy/studentforum/">
						<span class="msl-imagenav-title">StudentForum</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li></ul>
						</div>
				</div>
				<div class="support menu-list"><h1>Support</h1><div id="support-menu-id" class="mslwidget support-menu-id msl-imagenav">
				<ul><li><a href="/support/advicecentre/">
						<span class="msl-imagenav-title">AdviceCentre</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/support/campaigns/">
						<span class="msl-imagenav-title">Campaigns</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/support/nursery/">
						<span class="msl-imagenav-title">Nursery</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li></ul>
						</div>
				</div>
				<div class="shops menu-list"><h1>Shops</h1><div id="shops-menu-id" class="mslwidget shops-menu-id msl-imagenav">
				<ul><li><a href="/shops/costcutter/">
						<span class="msl-imagenav-title">Costcutter</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/shops/fultonoutfitters/">
						<span class="msl-imagenav-title">FultonOutfitters</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/shops/spars/">
						<span class="msl-imagenav-title">Spars</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/shops/travelshop/">
						<span class="msl-imagenav-title">TravelShop</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li></ul>
						</div>
				</div>
				<div class="venue menu-list"><h1>Venue</h1><div id="venu-menu-id" class="mslwidget venu-menu-id msl-imagenav">
				<ul><li><a href="/venues/divas/">
						<span class="msl-imagenav-title">Divas</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/venues/jcs/">
						<span class="msl-imagenav-title">JC's</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/venues/sincity/">
						<span class="msl-imagenav-title">SinCity</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li><li><a href="/venues/wonkeysheep/">
						<span class="msl-imagenav-title">Wonkey Sheep</span>
						
						<span class="msl-imagenav-description"></span>
						</a></li></ul>
						</div>
				</div>
			</div>

			<div id="menu-page-teaser">
				<div class="speech-bubble">
					<div class="teaser-image">
						<img src="img/su-logo.jpg" />
					</div>
					<div class="teaser-text">
						<p>Swansea University<br/>Students' Union<br/>phone: 01792 20 6029<br/>email: info@swansea-union.co.uk</p>
					</div>
				</div>
			</div>