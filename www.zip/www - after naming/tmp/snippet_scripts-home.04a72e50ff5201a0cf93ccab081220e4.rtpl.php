<?php if(!class_exists('raintpl')){exit;}?><!-- Master JS Files -->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="http://cdn.jquerytools.org/1.2.7/full/jquery.tools.min.js"></script>
<script type="text/javascript" src="js/su_modernizr-2.0.6-development-only.js"></script>
<script type="text/javascript" src="js/su_jquery.easing.1.3.js"></script>

<!-- Every Page -->
<script type="text/javascript" src="js/su_jquery.address-1.5.min.js"></script> <!-- Links -->
<script type="text/javascript" src="js/su_jquery.lightbox_me.js"></script> <!-- Lightbox -->
<script type="text/javascript" src="js/su_snippet_menu_jquery.typeahead.js"></script> <!-- Menu Typeahead -->
<script type="text/javascript" src="js/su_jquery.collapse.js"></script> <!-- jQuery Collapse -->
<script type="text/javascript" src="js/su_jquery.collapse_storage.js"></script> <!-- jQuery Collapse Storage -->
<script type="text/javascript" src="js/su_snippet_menu_jquery.menufication.min.js"></script> <!-- Menufication -->

<!-- This Page -->
<script type="text/javascript" src="js/su_jquery.isotope.js"></script> <!-- News -->
<script type="text/javascript" src="js/su_snippet_events_jquery.iosslider.min.js"></script> <!-- Slider -->
<script type="text/javascript" src="js/su_jquery.mousewheel.js"></script> <!-- Coverflow -->
<script type="text/javascript" src="js/su_snippet_coverflow_icarousel_raphael.min.js"></script> <!-- Coverflow -->
<script type="text/javascript" src="js/su_snippet_coverflow_icarousel.js"></script> <!-- Coverflow -->
<script type="text/javascript" src="js/su_snippet_media_jquery.social.stream.wall.1.3.js"></script> <!-- Media Wall -->
<script type="text/javascript" src="js/su_snippet_media_jquery.social.stream.1.5.1.js"></script> <!-- Media Wall -->

<!-- SU Scripts-->
<script type="text/javascript" src="js/su_data-2.0.js"></script> <!-- SU DATA -->
<script type="text/javascript" src="js/su_widgets.js"></script> <!-- Widget Builder -->
<script type="text/javascript" src="js/su_template_home.js"></script> <!-- Frontpage Scripts -->
<script type="text/javascript" src="js/su_snippet_menu.js"></script> <!-- Menu -->
<script type="text/javascript" src="js/su_common.js"></script>

<style>
.border { border: 1px solid #000; }
</style>

<!-- Important: SU_Data must be loaded before any other JS which uses Widget Data -->
