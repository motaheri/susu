<?php if(!class_exists('raintpl')){exit;}?><link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/normalize/2.0.1/normalize.css" />
<link href="./css/su_modern-buttons.css" rel="stylesheet">
<link href="./css/su_snippet_login.css" rel="stylesheet">
<div id="login-container">
		<div class="login-button-group">
			<div class="login-button login-as">Login As:</div>
			<div class="login-button m-btn blue">Swansea Uni Student</div>
			<div class="login-button m-btn green">Guest</div>
			<div class="login-button m-btn red">Staff</div>
		</div>
		</div>
	
		<div class="login-content swansea-uni-student">
			<div class="login-logo">&nbsp;</div>
			
			<div class="iframe-pop-container">
				 
				<iframe class="login-pop" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://www.swansea-union.co.uk/shib.ashx?ReturnUrl=/" <!--onLoad="reloadLogin()"--></iframe>
				 
				<br / >
			</div>
		</div>
		<div class="login-content guest green">
			<div class="login-logo"><span class="login-font">Guest</span></div>
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_login-gueststaff" );?>
		</div>
		<div class="login-content staff red">
			<div class="login-logo"><span class="login-font">Staff</span></div>
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_login-gueststaff" );?>
		</div>
		
		
		<div class="blocker">&nbsp;</div>
		<div class="login-help"><a href="#">Need Help?</a></div>
		</div>
</div>
