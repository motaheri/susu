<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<html>
    <head>
        <title>Swansea Student Events</title>
        
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_meta" );?>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_head" );?>
		
    </head>
    <body>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_menu" );?>
		
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_coverflow" );?>
		
		
		<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_advert" );?>
		
		<hr class="soft"/>
		
        <div id="main" class="clearfix">
			
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_news" );?>
			
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_events" );?>

			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_blogs" );?>
			
			<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_media" );?>

		</div>
		<hr class="soft"/>
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_footer" );?>
		
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_scripts-home" );?>
		<?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "snippet_scripts-facebook" );?>
		
        <?php $tpl = new RainTPL;$tpl->assign( $this->var );$tpl->draw( "widget_widgetdata" );?>
    </body>
</html>
