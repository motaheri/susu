<?php if(!class_exists('raintpl')){exit;}?>	   <div class="footer-container clearfix">  
			<footer>
				<div id="footer">  
					<div class="wrapper">
						<div class="two-column-left">
							<p>
							Swansea University Students' Union is here to support students and to make your experience the best it can be.
							</p>
							<div class="sponsors">
							<a href="http://swan.ac.uk/"><img class="su-icon" src="./img/sponsor-su.png"/></a>
							<a href="http://www.nus.org.uk/"><img class="nus-icon" src="./img/sponsor-nus.png"/></a>
							<a href="http://podio.com/"><img class="podio-icon" src="./img/sponsor-podio.png"/></a>
							<a href="http://www.dominos.co.uk/"><img class="dominos-icon" src="./img/sponsor-dominos.png"/></a>
							</div>
						</div>
						<div class="two-column-middle">
							<p>
							Students' Union, 
							Swansea University, 
							Union House, 
							Singleton Park, 
							Swansea, 
							SA2 8PP
							</p>
						</div>
						<div class="two-column-middle">
							<p><strong>Contact:</strong><br/>
							t: 01792 29 5466<br/>
							f: 01792 20 6029<br/>
							e: info@swansea-union.co.uk
							</p>
						</div>
						<div class="two-column-middle">
							<!--
							<div id="social-links">
								<a href="https://www.facebook.com/swanseauniversitystudentsunion" target="_blank" id="facebook"></a>
								<a href="https://twitter.com/SwanseaUnion" target="_blank" id="twitter"></a>
								<a href="http://www.youtube.com/user/StudentSwanseaEvents" target="_blank" id="youtube" class="last"></a>
							</div>
							<!--<h3>Sponsors</h3>-->
						</div>
						<div id="back-up" class="hand"> 
							<a class="center">
								<img src="./img/up.png"/>
							</a>
						</div>

					</div>
				</div>
			</footer>
	 	</div>
 