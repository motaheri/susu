<?php if(!class_exists('raintpl')){exit;}?>            <div class="news-container">
				<div class="wrapper">
					
					<h2 class="container-header"><img class="headericon news-icon" src="img/news-icon.png"/> News</h2>
					<div id="isonews">
					</div>
                    <div class="seemore">
                        More News...
                    </div>
					<div id="news-lightbox" class="sulb">
						<div class="sulb-inner news">
                            <div class="news-single">
                                <h2 class="title">Story Headline</h2>
                                <aside>
                                    <div id="page-badge">
                                        <div id="page-badge-photo">
                                            <img class="lead" />
                                        </div>
                                    </div>
                                    <ul class="nav nav-list">
                                        <li class="nav-header">Posted By</li>
                                        <li class="nav-exec">
                                            <img src="/img/activities/peopleBlank.jpg" />
                                            <div class="admin-people">
                                                <div class="organisation">Joe Bloggs</div>
                                                <div class="date">11th July 2013</div>
                                            </div>
                                        </li>
                                    </ul>
                                </aside>
                                <article>
                                    <div class="content">
                                    </div>
                                </article>
                            </div>
						</div>
						<div class="sulb-author"></div>
					</div>
				</div>
			</div>