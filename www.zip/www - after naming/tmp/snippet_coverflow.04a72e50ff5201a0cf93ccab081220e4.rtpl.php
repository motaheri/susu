<?php if(!class_exists('raintpl')){exit;}?>        <div id="coverflow" class="clearfix">
        </div>