<?php if(!class_exists('raintpl')){exit;}?><div class="advert-container">
	<div class="wrapper">

		<div id="advert">
			<div class="fulladvert">468 x 60</div>
			<div class="halfadvert">234 x 60</div>
			<div class="halfadvert">234 x 60</div>
			<div class="advertteaser">Advertisement Space</div>
		</div>
	</div>
</div>