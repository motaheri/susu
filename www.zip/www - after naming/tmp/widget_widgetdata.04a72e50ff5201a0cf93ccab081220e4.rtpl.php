<?php if(!class_exists('raintpl')){exit;}?><!--
/************************/
/* ACTIVITY WIDGET DATA */
/************************/
-->
	        <div class="mslwidget" style="display: none;">
<div class="msl_organisation_list">
        <div id="ctl00_activitiesSocieties_rptGroup_ctl01_pnlHeader" class="msl-gl-group">
            <h3>Academic</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl01_lnkLogo" href="/activities/6494/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl01_Logo1_imgLogo" src="../asset/Organisation/6494/AMSS%20logo.JPG?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="American Studies logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/6494/">American Studies</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl02_lnkLogo" href="/activities/6508/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/6508/ASlogo.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Ancient Studies logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/6508/">Ancient Studies</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl03_lnkLogo" href="/activities/bar/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/6522/Screen%20shot%202012-03-19%20at%2016.20.38.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Bar logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/bar/">Bar</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl04_lnkLogo" href="/activities/bigsoc/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/6536/bigsoc_logo%20(2).jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Bio Chemistry &amp; Genetics logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/bigsoc/">Bio Chemistry & Genetics</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl05_lnkLogo" href="/activities/Bioscience/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl05_Logo1_imgLogo" src="../asset/Organisation/6543/294597_10150399774695339_1919938442_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Bio Science logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/Bioscience/">Bio Science</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl06_lnkLogo" href="/activities/11096/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl06_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/11096/">Business</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl07_lnkLogo" href="/activities/6578/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl07_Logo1_imgLogo" src="../asset/Organisation/6578/Untitled.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Chemical Engineering logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/6578/">Chemical Engineering</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl08_lnkLogo" href="/activities/11158/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl08_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/11158/">Chemistry</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl09_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl09_lnkLogo" href="/activities/6634/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl09_Logo1_imgLogo" src="../asset/Organisation/6634/381573_10100546096919872_2029284580_a.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Criminology logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl09_lnkOrganisation" class="msl-gl-link" href="/activities/6634/">Criminology</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl10_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl10_lnkLogo" href="/activities/Economics/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl10_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl10_lnkOrganisation" class="msl-gl-link" href="/activities/Economics/">Economics</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl11_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl11_lnkLogo" href="/activities/EgyptologicalSociety/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl11_Logo1_imgLogo" src="../asset/Organisation/11050/46245_10151106894156616_171848416_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Egyptological logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl11_lnkOrganisation" class="msl-gl-link" href="/activities/EgyptologicalSociety/">Egyptological</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl12_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl12_lnkLogo" href="/activities/6690/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl12_Logo1_imgLogo" src="../asset/Organisation/6690/550457_179312618871199_460299055_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Engineering logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl12_lnkOrganisation" class="msl-gl-link" href="/activities/6690/">Engineering</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl13_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl13_lnkLogo" href="/activities/6697/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl13_Logo1_imgLogo" src="../asset/Organisation/6697/English_Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="English logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl13_lnkOrganisation" class="msl-gl-link" href="/activities/6697/">English</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl14_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl14_lnkLogo" href="/activities/french/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl14_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl14_lnkOrganisation" class="msl-gl-link" href="/activities/french/">French</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl15_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl15_lnkLogo" href="/activities/6725/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl15_Logo1_imgLogo" src="../asset/Organisation/6725/GEOGRAPHY.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Geography logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl15_lnkOrganisation" class="msl-gl-link" href="/activities/6725/">Geography</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl16_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl16_lnkLogo" href="/activities/Geology/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl16_Logo1_imgLogo" src="../asset/Organisation/6732/LOGO.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Geology logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl16_lnkOrganisation" class="msl-gl-link" href="/activities/Geology/">Geology</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl17_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl17_lnkLogo" href="/activities/german/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl17_Logo1_imgLogo" src="../asset/Organisation/6739/emailheader.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="German logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl17_lnkOrganisation" class="msl-gl-link" href="/activities/german/">German</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl18_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl18_lnkLogo" href="/activities/6760/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl18_Logo1_imgLogo" src="../asset/Organisation/6760/HAHA.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="HaHA (Human &amp; Health Sciences) logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl18_lnkOrganisation" class="msl-gl-link" href="/activities/6760/">HaHA (Human & Health Sciences)</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl19_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl19_lnkLogo" href="/activities/7508/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl19_Logo1_imgLogo" src="../asset/Organisation/7508/SWANSEA%20HISPANIC%20LOGO%202012.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Hispanic logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl19_lnkOrganisation" class="msl-gl-link" href="/activities/7508/">Hispanic</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl20_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl20_lnkLogo" href="/activities/history/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl20_Logo1_imgLogo" src="../asset/Organisation/6767/277115_209898062475242_335345616_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="History logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl20_lnkOrganisation" class="msl-gl-link" href="/activities/history/">History</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl21_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl21_lnkLogo" href="/activities/6809/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl21_Logo1_imgLogo" src="../asset/Organisation/6809/I%20love%20Italia.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Italian logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl21_lnkOrganisation" class="msl-gl-link" href="/activities/6809/">Italian</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl22_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl22_lnkLogo" href="/activities/lawsociety/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl22_Logo1_imgLogo" src="../asset/Organisation/6837/law.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Law logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl22_lnkOrganisation" class="msl-gl-link" href="/activities/lawsociety/">Law</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl23_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl23_lnkLogo" href="/activities/11144/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl23_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl23_lnkOrganisation" class="msl-gl-link" href="/activities/11144/">Marine Biology</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl24_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl24_lnkLogo" href="/activities/11062/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl24_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl24_lnkOrganisation" class="msl-gl-link" href="/activities/11062/">Mech & PD Soc</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl25_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl25_lnkLogo" href="/activities/11151/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl25_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl25_lnkOrganisation" class="msl-gl-link" href="/activities/11151/">Osteopathy</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl26_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl26_lnkLogo" href="/activities/6914/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl26_Logo1_imgLogo" src="../asset/Organisation/6914/PHYSICS.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Physics logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl26_lnkOrganisation" class="msl-gl-link" href="/activities/6914/">Physics</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl27_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl27_lnkLogo" href="/activities/PoliticsAndIR/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl27_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl27_lnkOrganisation" class="msl-gl-link" href="/activities/PoliticsAndIR/">Politics & IR</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl28_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl28_lnkLogo" href="/activities/7005/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl28_Logo1_imgLogo" src="../asset/Organisation/7005/41817_147316648621394_2549_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="SumSoc logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl28_lnkOrganisation" class="msl-gl-link" href="/activities/7005/">SumSoc</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl29_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl29_lnkLogo" href="/activities/7026/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl29_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl01_rptItems_ctl29_lnkOrganisation" class="msl-gl-link" href="/activities/7026/">War and Society</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSocieties_rptGroup_ctl02_pnlHeader" class="msl-gl-group">
            <h3>Charitable</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl01_lnkLogo" href="/activities/conservation_ecology/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl01_Logo1_imgLogo" src="../asset/Organisation/6620/391970_10150434486012223_1124336073_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Conservation Ecology logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/conservation_ecology/">Conservation Ecology</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl02_lnkLogo" href="/activities/coppafeel/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/10666/Coppafeel.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="CoppaFeel! logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/coppafeel/">CoppaFeel!</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl03_lnkLogo" href="/activities/6774/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/6774/Hitch%20banner.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Hitch logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/6774/">Hitch</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl04_lnkLogo" href="/activities/6998/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/6998/st%20john%20logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="St. John Links logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/6998/">St. John Links</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl05_lnkLogo" href="/activities/tester/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl05_Logo1_imgLogo" src="../asset/Organisation/7019/logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="UNICEF logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl02_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/tester/">UNICEF</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSocieties_rptGroup_ctl03_pnlHeader" class="msl-gl-group">
            <h3>Faith & Cultural</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl01_lnkLogo" href="/activities/6487/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl01_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/6487/">ACS</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl02_lnkLogo" href="/activities/10819/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/10819/brazil-flag.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Brazilian logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/10819/">Brazilian</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl03_lnkLogo" href="/activities/cathsoc/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/6571/cath%20soc%20logo.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="CathSoc logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/cathsoc/">CathSoc</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl04_lnkLogo" href="/activities/6585/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/6585/chinese.GIF?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Chinese logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/6585/">Chinese</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl05_lnkLogo" href="/activities/6599/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl05_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/6599/">Christian Union</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl06_lnkLogo" href="/activities/6788/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl06_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/6788/">Hong Kong</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl07_lnkLogo" href="/activities/7012/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl07_Logo1_imgLogo" src="../asset/Organisation/7012/india.gif?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Indian logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/7012/">Indian</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl08_lnkLogo" href="/activities/iraniansoc/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl08_Logo1_imgLogo" src="../asset/Organisation/10837/iran%20map.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Iranian logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/iraniansoc/">Iranian</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl09_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl09_lnkLogo" href="/activities/ISOC/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl09_Logo1_imgLogo" src="../asset/Organisation/6802/SwanseaISOClogo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Islamic logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl09_lnkOrganisation" class="msl-gl-link" href="/activities/ISOC/">Islamic</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl10_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl10_lnkLogo" href="/activities/10857/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl10_Logo1_imgLogo" src="../asset/Organisation/10857/Japanese%20Society%20Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Japanese logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl10_lnkOrganisation" class="msl-gl-link" href="/activities/10857/">Japanese</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl11_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl11_lnkLogo" href="/activities/jsocswansea/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl11_Logo1_imgLogo" src="../asset/Organisation/6816/new%20jsoc.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Jewish logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl11_lnkOrganisation" class="msl-gl-link" href="/activities/jsocswansea/">Jewish</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl12_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl12_lnkLogo" href="/activities/JPSS/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl12_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl12_lnkOrganisation" class="msl-gl-link" href="/activities/JPSS/">Jordanian Palestinian</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl13_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl13_lnkLogo" href="/activities/6823/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl13_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl13_lnkOrganisation" class="msl-gl-link" href="/activities/6823/">Kuwait</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl14_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl14_lnkLogo" href="/activities/6851/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl14_Logo1_imgLogo" src="../asset/Organisation/6851/300px-Flag_of_Malaysia_svg.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Malaysian logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl14_lnkOrganisation" class="msl-gl-link" href="/activities/6851/">Malaysian</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl15_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl15_lnkLogo" href="/activities/10769/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl15_Logo1_imgLogo" src="../asset/Organisation/10769/nigeria%20flag%203.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Nigerian logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl15_lnkOrganisation" class="msl-gl-link" href="/activities/10769/">Nigerian</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl16_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl16_lnkLogo" href="/activities/PaganSociety/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl16_Logo1_imgLogo" src="../asset/Organisation/6886/logo%20png%20copy.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Pagan logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl16_lnkOrganisation" class="msl-gl-link" href="/activities/PaganSociety/">Pagan</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl17_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl17_lnkLogo" href="/activities/6893/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl17_Logo1_imgLogo" src="../asset/Organisation/6893/PakSoc%20Logo%202012%20Black.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Pakistani logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl17_lnkOrganisation" class="msl-gl-link" href="/activities/6893/">Pakistani</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl18_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl18_lnkLogo" href="/activities/6984/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl18_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl03_rptItems_ctl18_lnkOrganisation" class="msl-gl-link" href="/activities/6984/">Scandinavian</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSocieties_rptGroup_ctl04_pnlHeader" class="msl-gl-group">
            <h3>Hobbies & Interests</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl01_lnkLogo" href="/activities/7605/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl01_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/7605/">Anime and Manga</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl02_lnkLogo" href="/activities/6529/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/6529/beer%20pong%20logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Beer Pong logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/6529/">Beer Pong</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl03_lnkLogo" href="/activities/6550/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/6550/Bright%20Futures.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Bright Futures logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/6550/">Bright Futures</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl04_lnkLogo" href="/activities/bslsociety/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/11081/bsls%20logo%20official.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="British Sign Language logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/bslsociety/">British Sign Language</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl05_lnkLogo" href="/activities/brony/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl05_Logo1_imgLogo" src="../asset/Organisation/6557/SwanseaUniBronyCrest.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Brony logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/brony/">Brony</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl06_lnkLogo" href="/activities/6564/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl06_Logo1_imgLogo" src="../asset/Organisation/6564/218890_10150195485188896_2239418_o.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="C.L.A.S.H. logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/6564/">C.L.A.S.H.</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl07_lnkLogo" href="/activities/7507/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl07_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/7507/">Chess</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl08_lnkLogo" href="/activities/sucs/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl08_Logo1_imgLogo" src="../asset/Organisation/6613/SUCSLOGO.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Computer (SUCS) logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/sucs/">Computer (SUCS)</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl09_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl09_lnkLogo" href="/activities/6648/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl09_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl09_lnkOrganisation" class="msl-gl-link" href="/activities/6648/">Dead Poets</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl10_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl10_lnkLogo" href="/activities/6655/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl10_Logo1_imgLogo" src="../asset/Organisation/6655/DEBATING.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Debating logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl10_lnkOrganisation" class="msl-gl-link" href="/activities/6655/">Debating</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl11_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl11_lnkLogo" href="/activities/6669/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl11_Logo1_imgLogo" src="../asset/Organisation/6669/DofE.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Duke of Edinburgh logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl11_lnkOrganisation" class="msl-gl-link" href="/activities/6669/">Duke of Edinburgh</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl12_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl12_lnkLogo" href="/activities/6704/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl12_Logo1_imgLogo" src="../asset/Organisation/6704/ewb%20hoody%20final%203.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="EWB logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl12_lnkOrganisation" class="msl-gl-link" href="/activities/6704/">EWB</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl13_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl13_lnkLogo" href="/activities/6711/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl13_Logo1_imgLogo" src="../asset/Organisation/6711/Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Fashion logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl13_lnkOrganisation" class="msl-gl-link" href="/activities/6711/">Fashion</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl14_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl14_lnkLogo" href="/activities/6718/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl14_Logo1_imgLogo" src="../asset/Organisation/6718/FILM.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Film logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl14_lnkOrganisation" class="msl-gl-link" href="/activities/6718/">Film</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl15_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl15_lnkLogo" href="/activities/10917/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl15_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl15_lnkOrganisation" class="msl-gl-link" href="/activities/10917/">Gaming</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl16_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl16_lnkLogo" href="/activities/SSWIGS/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl16_Logo1_imgLogo" src="../asset/Organisation/6963/New%20Square%20Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Guides and Scouts logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl16_lnkOrganisation" class="msl-gl-link" href="/activities/SSWIGS/">Guides and Scouts</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl17_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl17_lnkLogo" href="/activities/swanseahogwarts/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl17_Logo1_imgLogo" src="../asset/Organisation/6781/SHS%20Crest.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Hogwarts logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl17_lnkOrganisation" class="msl-gl-link" href="/activities/swanseahogwarts/">Hogwarts</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl18_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl18_lnkLogo" href="/activities/11172/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl18_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl18_lnkOrganisation" class="msl-gl-link" href="/activities/11172/">Investment and Finance</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl19_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl19_lnkLogo" href="/activities/11121/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl19_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl19_lnkOrganisation" class="msl-gl-link" href="/activities/11121/">Konetics</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl20_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl20_lnkLogo" href="/activities/marvelsociety101/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl20_Logo1_imgLogo" src="../asset/Organisation/11165/marvel%20logo.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Marvel logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl20_lnkOrganisation" class="msl-gl-link" href="/activities/marvelsociety101/">Marvel</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl21_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl21_lnkLogo" href="/activities/7548/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl21_Logo1_imgLogo" src="../asset/Organisation/7548/logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="OTC logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl21_lnkOrganisation" class="msl-gl-link" href="/activities/7548/">OTC</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl22_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl22_lnkLogo" href="/activities/10677/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl22_Logo1_imgLogo" src="../asset/Organisation/10677/polefitness_logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Pole Fitness logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl22_lnkOrganisation" class="msl-gl-link" href="/activities/10677/">Pole Fitness</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl23_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl23_lnkLogo" href="/activities/6942/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl23_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl23_lnkOrganisation" class="msl-gl-link" href="/activities/6942/">Real Ale</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl24_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl24_lnkLogo" href="/activities/6949/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl24_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl24_lnkOrganisation" class="msl-gl-link" href="/activities/6949/">Roleplay</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl25_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl25_lnkLogo" href="/activities/enactus/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl25_Logo1_imgLogo" src="../asset/Organisation/6956/SwanseaGreyTransTrim.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="S.I.F.E. logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl25_lnkOrganisation" class="msl-gl-link" href="/activities/enactus/">S.I.F.E.</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl26_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl26_lnkLogo" href="/activities/6991/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl26_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl26_lnkOrganisation" class="msl-gl-link" href="/activities/6991/">Sci-Fi</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl27_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl27_lnkLogo" href="/activities/SwanC/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl27_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl27_lnkOrganisation" class="msl-gl-link" href="/activities/SwanC/">SwanC</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl28_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl28_lnkLogo" href="/activities/7510/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl28_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl28_lnkOrganisation" class="msl-gl-link" href="/activities/7510/">UWAS</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl29_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl29_lnkLogo" href="/activities/7033/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl29_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl29_lnkOrganisation" class="msl-gl-link" href="/activities/7033/">Wargaming</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl30_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl30_lnkLogo" href="/activities/WURNU/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl30_Logo1_imgLogo" src="../asset/Organisation/7040/Wales%20URNU%20Society%20Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="WURNU logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl30_lnkOrganisation" class="msl-gl-link" href="/activities/WURNU/">WURNU</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl31_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl31_lnkLogo" href="/activities/ygymdeithasgymraeg/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl31_Logo1_imgLogo" src="../asset/Organisation/7054/Swan%20y%20Gym%20Gym.gif?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Y Gym Gym logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl31_lnkOrganisation" class="msl-gl-link" href="/activities/ygymdeithasgymraeg/">Y Gym Gym</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl32_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl32_lnkLogo" href="/activities/yoga/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl32_Logo1_imgLogo" src="../asset/Organisation/10671/iyengar-certificate-logoT.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Yoga logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl04_rptItems_ctl32_lnkOrganisation" class="msl-gl-link" href="/activities/yoga/">Yoga</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSocieties_rptGroup_ctl05_pnlHeader" class="msl-gl-group">
            <h3>Media</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl01_lnkLogo" href="/activities/SUMediaSoc/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl01_Logo1_imgLogo" src="../asset/Organisation/6858/SUMS.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Media logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/SUMediaSoc/">Media</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl02_lnkLogo" href="/activities/Photography/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/6907/276993_132939250065212_978747252_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Photography logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/Photography/">Photography</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl03_lnkLogo" href="/activities/7047/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/7047/xtreme%20radio.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Xtreme Radio logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl05_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/7047/">Xtreme Radio</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSocieties_rptGroup_ctl06_pnlHeader" class="msl-gl-group">
            <h3>Performing Arts</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl01_lnkLogo" href="/activities/Choral/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl01_Logo1_imgLogo" src="../asset/Organisation/6592/Choral.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Choral logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/Choral/">Choral</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl02_lnkLogo" href="/activities/6606/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl02_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/6606/">Comedy</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl03_lnkLogo" href="/activities/dancesociety/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/6641/Dance%20Society%20Logo%20(Small%20on%20front,%20Large%20on%20back).jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Dance logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/dancesociety/">Dance</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl04_lnkLogo" href="/activities/shoreline/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/6662/Shoreline.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Drama (Shoreline Theatre) logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/shoreline/">Drama (Shoreline Theatre)</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl05_lnkLogo" href="/activities/6746/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl05_Logo1_imgLogo" src="../asset/Organisation/6746/glee%20logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Glee logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/6746/">Glee</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl06_lnkLogo" href="/activities/6753/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl06_Logo1_imgLogo" src="../asset/Organisation/6753/gospel.gif?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Gospel Choir logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/6753/">Gospel Choir</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl07_lnkLogo" href="/activities/livemusicsociety/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl07_Logo1_imgLogo" src="../asset/Organisation/6515/21502_425136920880416_1928375058_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Live Music logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/livemusicsociety/">Live Music</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl08_lnkLogo" href="/activities/6865/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl08_Logo1_imgLogo" src="../asset/Organisation/6865/019.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Musicians logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl06_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/6865/">Musicians</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSocieties_rptGroup_ctl07_pnlHeader" class="msl-gl-group">
            <h3>Political & Campaigning</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl01_lnkLogo" href="/activities/Amnesty/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl01_Logo1_imgLogo" src="../asset/Organisation/6501/amnesty.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Amnesty International logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/Amnesty/">Amnesty International</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl02_lnkLogo" href="/activities/conservatives/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/6627/future_logo_full_col.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Conservative Future logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/conservatives/">Conservative Future</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl03_lnkLogo" href="/activities/6795/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/6795/hras_logo%5B1%5D.JPG?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Human Rights Action logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/6795/">Human Rights Action</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl04_lnkLogo" href="/activities/SwanseaLabourStudent/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/6830/swansealabstudents.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Labour Students logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/SwanseaLabourStudent/">Labour Students</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl05_lnkLogo" href="/activities/lgbtplus/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl05_Logo1_imgLogo" src="../asset/Organisation/6844/logo-white%20text.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="LGBT+ logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/lgbtplus/">LGBT+</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl06_lnkLogo" href="/activities/liberalyouth/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl06_Logo1_imgLogo" src="../asset/Organisation/7509/swansea-liberal-yoith-logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Liberal Youth logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/liberalyouth/">Liberal Youth</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl07_lnkLogo" href="/activities/10955/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl07_Logo1_imgLogo" src="../asset/Organisation/10955/Mental%20Wealth.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Mental Wealth logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/10955/">Mental Wealth</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl08_lnkLogo" href="/activities/11088/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl08_Logo1_imgLogo" src="../asset/Organisation/11088/563493_10151501890018162_1238113179_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Palestinian Solidarity logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/11088/">Palestinian Solidarity</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl09_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl09_lnkLogo" href="/activities/People-and-Planet/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl09_Logo1_imgLogo" src="../asset/Organisation/6900/people%20and%20planet_59.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="People &amp; Planet logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl09_lnkOrganisation" class="msl-gl-link" href="/activities/People-and-Planet/">People & Planet</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl10_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl10_lnkLogo" href="/activities/Events/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl10_Logo1_imgLogo" src="../asset/Organisation/6921/pyouth.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Plaid Cymru logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl10_lnkOrganisation" class="msl-gl-link" href="/activities/Events/">Plaid Cymru</a>
                </li>
                <li id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl11_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl11_lnkLogo" href="/activities/socialist_students/"><div class="mslwidget">
<img id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl11_Logo1_imgLogo" src="../asset/Organisation/10902/logo2009.gif?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Socialist Students logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSocieties_rptGroup_ctl07_rptItems_ctl11_lnkOrganisation" class="msl-gl-link" href="/activities/socialist_students/">Socialist Students</a>
                </li>
            </ul>
    </div>
</div>
<div class="mslwidget" style="display: none;">
<div class="msl_organisation_list">
        <div id="ctl00_activitiesSport_rptGroup_ctl01_pnlHeader" class="msl-gl-group">
            <h3>Ball Based Sports</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl01_lnkLogo" href="/activities/7068/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl01_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/7068/">American Football</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl02_lnkLogo" href="/activities/7082/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/7082/820863_682469825734_30851841_o.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Badminton logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/7082/">Badminton</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl03_lnkLogo" href="/activities/7089/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl03_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/7089/">Basketball</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl04_lnkLogo" href="/activities/cricket/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/7117/image.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Cricket logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/cricket/">Cricket</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl05_lnkLogo" href="/activities/7138/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl05_Logo1_imgLogo" src="../asset/Organisation/7138/about%20us.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Football Women's logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/7138/">Football Women's</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl06_lnkLogo" href="/activities/swanseaunigolfclub/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl06_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/swanseaunigolfclub/">Golf</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl07_lnkLogo" href="/activities/7166/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl07_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/7166/">Hockey Men's</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl08_lnkLogo" href="/activities/hockeywomens/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl08_Logo1_imgLogo" src="../asset/Organisation/7173/Varsity%202012.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Hockey Women's logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/hockeywomens/">Hockey Women's</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl09_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl09_lnkLogo" href="/activities/7180/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl09_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl09_lnkOrganisation" class="msl-gl-link" href="/activities/7180/">Intramural Football</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl10_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl10_lnkLogo" href="/activities/Lacrosse/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl10_Logo1_imgLogo" src="../asset/Organisation/7222/Lax.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Lacrosse logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl10_lnkOrganisation" class="msl-gl-link" href="/activities/Lacrosse/">Lacrosse</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl11_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl11_lnkLogo" href="/activities/mensfootball/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl11_Logo1_imgLogo" src="../asset/Organisation/7131/Swan-Uni-WoGLogo-2.gif?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Mens Football logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl11_lnkOrganisation" class="msl-gl-link" href="/activities/mensfootball/">Mens Football</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl12_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl12_lnkLogo" href="/activities/7250/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl12_Logo1_imgLogo" src="../asset/Organisation/7250/427535_10150581901042581_763950991_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Netball logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl12_lnkOrganisation" class="msl-gl-link" href="/activities/7250/">Netball</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl13_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl13_lnkLogo" href="/activities/7264/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl13_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl13_lnkOrganisation" class="msl-gl-link" href="/activities/7264/">Rugby League</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl14_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl14_lnkLogo" href="/activities/7271/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl14_Logo1_imgLogo" src="../asset/Organisation/7271/rugby%20logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Rugby Union Men's logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl14_lnkOrganisation" class="msl-gl-link" href="/activities/7271/">Rugby Union Men's</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl15_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl15_lnkLogo" href="/activities/rugbyunionwomens/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl15_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl15_lnkOrganisation" class="msl-gl-link" href="/activities/rugbyunionwomens/">Rugby Union Women's</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl16_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl16_lnkLogo" href="/activities/7306/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl16_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl16_lnkOrganisation" class="msl-gl-link" href="/activities/7306/">Squash</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl17_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl17_lnkLogo" href="/activities/7341/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl17_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl17_lnkOrganisation" class="msl-gl-link" href="/activities/7341/">Tennis</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl18_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl18_lnkLogo" href="/activities/volleyball/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl18_Logo1_imgLogo" src="../asset/Organisation/7362/Club%20photo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Volleyball logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl01_rptItems_ctl18_lnkOrganisation" class="msl-gl-link" href="/activities/volleyball/">Volleyball</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSport_rptGroup_ctl02_pnlHeader" class="msl-gl-group">
            <h3>Martial Arts</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl01_lnkLogo" href="/activities/7061/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl01_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/7061/">Aikido</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl02_lnkLogo" href="/activities/7096/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/7096/n539536214_2152072_2856%5B1%5D.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Boxing logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/7096/">Boxing</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl03_lnkLogo" href="/activities/7187/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/7187/559740_10150661330738248_555062162_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Jiu Jitsu logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/7187/">Jiu Jitsu</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl04_lnkLogo" href="/activities/7201/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/7201/Swansea%20Uni%20karate.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Karate logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/7201/">Karate</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl05_lnkLogo" href="/activities/7208/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl05_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/7208/">Kickboxing</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl06_lnkLogo" href="/activities/7334/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl06_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl02_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/7334/">Tae Kwon Do</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSport_rptGroup_ctl03_pnlHeader" class="msl-gl-group">
            <h3>Other Sports</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl01_lnkLogo" href="/activities/7075/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl01_Logo1_imgLogo" src="../asset/Organisation/7075/tba.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Archery logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/7075/">Archery</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl02_lnkLogo" href="/activities/Cheerleading/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl02_Logo1_imgLogo" src="../asset/Organisation/7110/315538_162648140489248_283103433_n.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Cheerleading logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/Cheerleading/">Cheerleading</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl03_lnkLogo" href="/activities/7236/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl03_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/7236/">Cycling</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl04_lnkLogo" href="/activities/Equestrian/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/7124/Equestrian%20Club%20%20New%20Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Equestrian logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/Equestrian/">Equestrian</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl05_lnkLogo" href="/activities/SwanUFencing/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl05_Logo1_imgLogo" src="../asset/Organisation/7145/Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Fencing logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/SwanUFencing/">Fencing</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl06_lnkLogo" href="/activities/7159/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl06_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/7159/">Hiking</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl07_lnkLogo" href="/activities/7194/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl07_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/7194/">Karting</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl08_lnkLogo" href="/activities/SUMC/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl08_Logo1_imgLogo" src="../asset/Organisation/7243/SUMC%20logo.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Mountaineering logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/SUMC/">Mountaineering</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl09_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl09_lnkLogo" href="/activities/SU_AthleticsClub/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl09_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl09_lnkOrganisation" class="msl-gl-link" href="/activities/SU_AthleticsClub/">Running</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl10_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl10_lnkLogo" href="/activities/SwanseaSnowriders/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl10_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl10_lnkOrganisation" class="msl-gl-link" href="/activities/SwanseaSnowriders/">Snowriders</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl11_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl11_lnkLogo" href="/activities/7348/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl11_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl11_lnkOrganisation" class="msl-gl-link" href="/activities/7348/">Triathlon</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl12_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl12_lnkLogo" href="/activities/Ultimate/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl12_Logo1_imgLogo" src="../asset/Organisation/7355/582677_314930658608466_1567955291_n.png?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Ultimate Frisbee logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl03_rptItems_ctl12_lnkOrganisation" class="msl-gl-link" href="/activities/Ultimate/">Ultimate Frisbee</a>
                </li>
            </ul>
        <div id="ctl00_activitiesSport_rptGroup_ctl04_pnlHeader" class="msl-gl-group">
            <h3>Water Sports</h3>
</div>
        <ul class="msl_organisation_list">
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl01_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl01_lnkLogo" href="/activities/CanoeClub/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl01_Logo1_imgLogo" src="../asset/Organisation/7103/LyjeXy2yQuGyDaVeXedu.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Canoe Club logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl01_lnkOrganisation" class="msl-gl-link" href="/activities/CanoeClub/">Canoe Club</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl02_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl02_lnkLogo" href="/activities/7215/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl02_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl02_lnkOrganisation" class="msl-gl-link" href="/activities/7215/">Kitesurfing</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl03_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl03_lnkLogo" href="/activities/7229/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl03_Logo1_imgLogo" src="../asset/Organisation/7229/Lifesaving%20Luisa.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Lifesaving logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl03_lnkOrganisation" class="msl-gl-link" href="/activities/7229/">Lifesaving</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl04_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl04_lnkLogo" href="/activities/SwanseaUniRowingClub/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl04_Logo1_imgLogo" src="../asset/Organisation/7257/SURC_Logo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Rowing logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl04_lnkOrganisation" class="msl-gl-link" href="/activities/SwanseaUniRowingClub/">Rowing</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl05_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl05_lnkLogo" href="/activities/Sailing/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl05_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl05_lnkOrganisation" class="msl-gl-link" href="/activities/Sailing/">Sailing</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl06_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl06_lnkLogo" href="/activities/7313/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl06_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl06_lnkOrganisation" class="msl-gl-link" href="/activities/7313/">Sub Aqua</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl07_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl07_lnkLogo" href="/activities/7320/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl07_Logo1_imgLogo" src="../asset/Organisation/7320/SU_Photo.jpg?thumbnail_width=218&amp;thumbnail_height=160&amp;resize_type=ResizeFitAll" alt="Surf logo" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl07_lnkOrganisation" class="msl-gl-link" href="/activities/7320/">Surf</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl08_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl08_lnkLogo" href="/activities/7327/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl08_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl08_lnkOrganisation" class="msl-gl-link" href="/activities/7327/">Swimming</a>
                </li>
                <li id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl09_liLogo" class="msl-gl-logo">
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl09_lnkLogo" href="/activities/7369/"><div class="mslwidget">
<img id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl09_Logo1_imgLogo" src="/assets/default_images/218x160/default_grouping_logo.jpg" style="border-width:0px;" />
</div></a>
                </li>
		        <li>
                    <a id="ctl00_activitiesSport_rptGroup_ctl04_rptItems_ctl09_lnkOrganisation" class="msl-gl-link" href="/activities/7369/">Windsurfing</a>
                </li>
            </ul>
    </div>
</div>
<!--
/**********************/
/* MIKE'S WIDGET DATA */
/**********************/
-->
<div id="MyMemberships" class="mslwidget" style="display: none;">
<div>
		<dl class="memberships" data-msl-organisation-id="6019" data-msl-grouping-id="6522">
			<dt><a class="membership" href="/activities/bar/">Bar</a></dt>
		</dl>
		<dl class="memberships" data-msl-organisation-id="6019" data-msl-grouping-id="7047">
			<dt><a class="membership" href="/activities/7047/">Xtreme Radio</a></dt>
		</dl>
		<dl class="memberships" data-msl-organisation-id="7391" data-msl-grouping-id="6109">
			<dt><a class="membership" href="/activities/sportswansea/">Sport Swansea</a></dt>
		</dl>
</div>
</div>
<!--
EVENT DATA
-->

<div id="eventsmain" class="mslwidget" style="display: none;">

<div class="msl_eventlist">
            <div>
			
			
			
			
			            <div class="event_item item1 itemOdd mslorg6042 msltypelivemusic msltypeclubnights msltypesocieties msltypespecialevents msltypesummerball" data-msl-organisation-id="6042">

			                <dl>
				                <dt>
                                    <a href="../../ents/event/521/"><span class="msl_event_image"><img src="/asset/Event/6042/gradball13_couple_a3.jpg?thumbnail_width=461&thumbnail_height=215&resize_type=CropToFit" alt="" /></span></a>
                                    
                                    <a href="/ents/event/521/" class="msl_event_name">Graduation Ball</a>
                                </dt>
				
                                <dd class="msl_event_time">10th July 8pm - 1am</dd>
				
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description"></dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/521/">Buy Tickets</a>
                                </dd>

                                

				                

				                <dd class="msl_event_hook" />

			                </dl>

                        </div>

			
		
			
			
			
			
                        <div class="event_item item1 itemOdd msl-brand-gigslivemusic" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/552/"><span class="msl_event_image"><img src="/asset/Event/6050/tct_poster.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/552/" class="msl_event_name">Ten Cent Toy</a>
                                </dt>
                                <dd class="msl_event_time">15th May 7:30pm - 11pm</dd>
                                <dd class="msl_event_location">Sin City</dd>

				                <dd class="msl_event_description">Ten Cent Toy with support from Fourth Autumn / The Exiled / Storm the Walls and All to Ruin</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/552/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">gigslivemusic</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item2 itemEven msl-brand-playonwednesdays" data-msl-organisation-id="8390">

			                <dl>
				                <dt>
                                    <a href="../ents/event/531/"><span class="msl_event_image"><img src="/asset/Event/8390/picknmix.png?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Odyssey</span>
                                    <a href="/ents/event/531/" class="msl_event_name">PlayOn Wednesdays :: Pick &amp; Mix</a>
                                </dt>
                                <dd class="msl_event_time">15th May 9pm - 3:30am</dd>
                                <dd class="msl_event_location">Odyssey</dd>

				                <dd class="msl_event_description">The home of Sport Swansea - PlayOn Wednesdays is the club night of the Green and White Army!</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/531/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">playonwednesdays</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item3 itemOdd msl-brand-sinsavers" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/537/"><span class="msl_event_image"><img src="/asset/Event/6050/527647_10150874850848579_1378156209_n.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/537/" class="msl_event_name">sinsavers</a>
                                </dt>
                                <dd class="msl_event_time">16th May 10pm - 2:30am</dd>
                                <dd class="msl_event_location">Sin CIty</dd>

				                <dd class="msl_event_description">The only night in Swansea with censored drinks prices and an anything goes attitude.</dd>
                                <dd class="msl_event_brand">sinsavers</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item4 itemEven msl-brand-tooters" data-msl-organisation-id="8387">

			                <dl>
				                <dt>
                                    <a href="../ents/event/361/"><span class="msl_event_image"><img src="/asset/Event/8387/tooters-tall.png?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Divas</span>
                                    <a href="/ents/event/361/" class="msl_event_name">tooters</a>
                                </dt>
                                <dd class="msl_event_time">17th May 9pm - 2am</dd>
                                <dd class="msl_event_location">Divas</dd>

				                <dd class="msl_event_description">2 Drinks for �2 - 2 Rooms - 2 DJ's - 2 Many Stories</dd>
                                <dd class="msl_event_brand">tooters</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item5 itemOdd msl-brand-sink" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/546/"></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/546/" class="msl_event_name">sink</a>
                                </dt>
                                <dd class="msl_event_time">18th May 10pm - 3am</dd>
                                <dd class="msl_event_location">Sin city</dd>

				                <dd class="msl_event_description">Sink is an amazing fusion of Music, Art &amp; Dancing.</dd>
                                <dd class="msl_event_brand">sink</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item6 itemEven msl-brand-ilovemondays" data-msl-organisation-id="8388">

			                <dl>
				                <dt>
                                    <a href="../ents/event/528/"><span class="msl_event_image"><img src="/asset/Event/8388/ihateexamsweb.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Oceana</span>
                                    <a href="/ents/event/528/" class="msl_event_name">istillhateexams</a>
                                </dt>
                                <dd class="msl_event_time">20th May 10pm - 3am</dd>
                                <dd class="msl_event_location">Oceana</dd>

				                <dd class="msl_event_description">Swansea University's flagship night; ilovemondays - but hate Tuesday mornings!</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/528/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">ilovemondays</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item7 itemOdd msl-brand-playonwednesdays" data-msl-organisation-id="8390">

			                <dl>
				                <dt>
                                    <a href="../ents/event/532/"><span class="msl_event_image"><img src="/asset/Event/8390/RockstarWEBlight.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Odyssey</span>
                                    <a href="/ents/event/532/" class="msl_event_name">PlayOn Like A Rockstar</a>
                                </dt>
                                <dd class="msl_event_time">22nd May 9pm - 3:30am</dd>
                                <dd class="msl_event_location">Odyssey</dd>

				                <dd class="msl_event_description">The home of Sport Swansea - PlayOn Wednesdays is the club night of the Green and White Army!</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/532/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">playonwednesdays</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item8 itemEven msl-brand-sinsavers" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/538/"><span class="msl_event_image"><img src="/asset/Event/6050/527647_10150874850848579_1378156209_n.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/538/" class="msl_event_name">sinsavers</a>
                                </dt>
                                <dd class="msl_event_time">23rd May 10pm - 2:30am</dd>
                                <dd class="msl_event_location">Sin CIty</dd>

				                <dd class="msl_event_description">The only night in Swansea with censored drinks prices and an anything goes attitude.</dd>
                                <dd class="msl_event_brand">sinsavers</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item9 itemOdd msl-brand-tooters" data-msl-organisation-id="8387">

			                <dl>
				                <dt>
                                    <a href="../ents/event/362/"></a>
                                    <span class="msl_event_organisation">Divas</span>
                                    <a href="/ents/event/362/" class="msl_event_name">tooters</a>
                                </dt>
                                <dd class="msl_event_time">24th May 9pm - 2am</dd>
                                <dd class="msl_event_location">Divas</dd>

				                <dd class="msl_event_description">2 Drinks for �2 - 2 Rooms - 2 DJ's - 2 Many Stories</dd>
                                <dd class="msl_event_brand">tooters</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item10 itemEven msl-brand-gigslivemusic" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/523/"><span class="msl_event_image"><img src="/asset/Event/6050/Abyssinian-swansea-Poster.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/523/" class="msl_event_name">Abyssiinians</a>
                                </dt>
                                <dd class="msl_event_time">25th May 7:30pm - 11pm</dd>
                                <dd class="msl_event_location">Sin City Swansea</dd>

				                <dd class="msl_event_description">The Abyssinians are a Jamaican roots reggae group, famous for their close harmonies and promotion of the Rastafari movement in their lyrics.</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/523/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">gigslivemusic</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item11 itemOdd msl-brand-sink" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/547/"></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/547/" class="msl_event_name">sink</a>
                                </dt>
                                <dd class="msl_event_time">25th May 10pm - 3am</dd>
                                <dd class="msl_event_location">Sin city</dd>

				                <dd class="msl_event_description">Sink is an amazing fusion of Music, Art &amp; Dancing.</dd>
                                <dd class="msl_event_brand">sink</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item12 itemEven msl-brand-ilovemondays" data-msl-organisation-id="8388">

			                <dl>
				                <dt>
                                    <a href="../ents/event/529/"><span class="msl_event_image"><img src="/asset/Event/8388/ilovemondays.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Oceana</span>
                                    <a href="/ents/event/529/" class="msl_event_name">ilovemessymondays</a>
                                </dt>
                                <dd class="msl_event_time">27th May 10pm - 3am</dd>
                                <dd class="msl_event_location">Oceana</dd>

				                <dd class="msl_event_description">Swansea University's flagship night; ilovemondays - but hate Tuesday mornings!</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/529/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">ilovemondays</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item13 itemOdd msl-brand-flux" data-msl-organisation-id="8387">

			                <dl>
				                <dt>
                                    <a href="../ents/event/386/"><span class="msl_event_image"><img src="/asset/Event/8387/flux.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Divas</span>
                                    <a href="/ents/event/386/" class="msl_event_name">flux</a>
                                </dt>
                                <dd class="msl_event_time">28th May 9pm - 2am</dd>
                                <dd class="msl_event_location">Divas</dd>

				                <dd class="msl_event_description">Tuesdays? I'm in Flux. Swansea's very own Indie night.</dd>
                                <dd class="msl_event_brand">flux</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item14 itemEven msl-brand-playonwednesdays" data-msl-organisation-id="8390">

			                <dl>
				                <dt>
                                    <a href="../ents/event/533/"><span class="msl_event_image"><img src="/asset/Event/8390/PlayOn_1024.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Odyssey</span>
                                    <a href="/ents/event/533/" class="msl_event_name">PlayOn Wednesdays :: Class Of 2013</a>
                                </dt>
                                <dd class="msl_event_time">29th May 9pm - 3:30am</dd>
                                <dd class="msl_event_location">Odyssey</dd>

				                <dd class="msl_event_description">The home of Sport Swansea - PlayOn Wednesdays is the club night of the Green and White Army!</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/533/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">playonwednesdays</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item15 itemOdd msl-brand-gigslivemusic" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/534/"><span class="msl_event_image"><img src="/asset/Event/6050/kingsfoil_poster.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/534/" class="msl_event_name">Kingsfoil | Featuring Frankie Muniz</a>
                                </dt>
                                <dd class="msl_event_time">30th May 7:30pm - 11pm</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description">Kingsfoil take to the Sin City stage - featuring Frankie Muniz of Malcom in the Middle fame.</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/534/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">gigslivemusic</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item16 itemEven msl-brand-sinsavers" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/539/"><span class="msl_event_image"><img src="/asset/Event/6050/527647_10150874850848579_1378156209_n.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/539/" class="msl_event_name">sinsavers</a>
                                </dt>
                                <dd class="msl_event_time">30th May 10pm - 2:30am</dd>
                                <dd class="msl_event_location">Sin CIty</dd>

				                <dd class="msl_event_description">The only night in Swansea with censored drinks prices and an anything goes attitude.</dd>
                                <dd class="msl_event_brand">sinsavers</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item17 itemOdd msl-brand-tooters" data-msl-organisation-id="8387">

			                <dl>
				                <dt>
                                    <a href="../ents/event/363/"></a>
                                    <span class="msl_event_organisation">Divas</span>
                                    <a href="/ents/event/363/" class="msl_event_name">tooters</a>
                                </dt>
                                <dd class="msl_event_time">31st May 9pm - 2am</dd>
                                <dd class="msl_event_location">Divas</dd>

				                <dd class="msl_event_description">2 Drinks for �2 - 2 Rooms - 2 DJ's - 2 Many Stories</dd>
                                <dd class="msl_event_brand">tooters</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item18 itemEven msl-brand-gigslivemusic" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/551/"><span class="msl_event_image"><img src="/asset/Event/6050/Lewis-Watson_UKJuneTourPoster_v2.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/551/" class="msl_event_name">Lewis Watson</a>
                                </dt>
                                <dd class="msl_event_time">1st June 7pm - 10:30pm</dd>
                                <dd class="msl_event_location">Sin City</dd>

				                <dd class="msl_event_description">Lewis Watson follows in the footsteps of Ed Sheeran and Ben Howard</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/551/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">gigslivemusic</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item19 itemOdd msl-brand-sink" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/548/"></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/548/" class="msl_event_name">sink</a>
                                </dt>
                                <dd class="msl_event_time">1st June 10pm - 3am</dd>
                                <dd class="msl_event_location">Sin city</dd>

				                <dd class="msl_event_description">Sink is an amazing fusion of Music, Art &amp; Dancing.</dd>
                                <dd class="msl_event_brand">sink</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item20 itemEven msl-brand-sinsavers" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/550/"><span class="msl_event_image"><img src="/asset/Event/6050/sindependence_june13.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/550/" class="msl_event_name">Sinkdependance Day</a>
                                </dt>
                                <dd class="msl_event_time">1st June 10pm - 3am</dd>
                                <dd class="msl_event_location">Sin City Swansea</dd>

				                <dd class="msl_event_description">Sink vs Sin Savers ... On a Saturday... Anything could happen!</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/550/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">sinsavers</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
						                 | 
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item21 itemOdd msl-brand-summerball" data-msl-organisation-id="6042">

			                <dl>
				                <dt>
                                    <a href="../ents/event/497/"><span class="msl_event_image"><img src="/asset/Event/6042/mainmsl.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Entertainments</span>
                                    <a href="/ents/event/497/" class="msl_event_name">Summer Ball 2013 #SSB13</a>
                                </dt>
                                <dd class="msl_event_time">3rd June 4pm - 11:59pm</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description"></dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/497/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">summerball</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
						                 | 
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
						                 | 
                                            <a href="/ents/eventlist/societies/">Societies</a>
						                 | 
                                            <a href="/ents/eventlist/union/">Union Events</a>
						                 | 
                                            <a href="/ents/eventlist/specialevents/">Special Event</a>
						                 | 
                                            <a href="/ents/eventlist/freshers/">Fresher Events</a>
						                 | 
                                            <a href="/ents/eventlist/partypacks/">Party Packages</a>
						                 | 
                                            <a href="/ents/eventlist/summerball/">Summer Ball</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item22 itemEven msl-brand-summerball" data-msl-organisation-id="6042">

			                <dl>
				                <dt>
                                    <a href="../ents/event/501/"><span class="msl_event_image"><img src="/asset/Event/6042/summergrad.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Entertainments</span>
                                    <a href="/ents/event/501/" class="msl_event_name">Summer and Graduation Combo</a>
                                </dt>
                                <dd class="msl_event_time">3rd June 4:01pm - 11:59pm</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description">Graduation Combination Discount</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/501/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">summerball</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
						                 | 
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
						                 | 
                                            <a href="/ents/eventlist/societies/">Societies</a>
						                 | 
                                            <a href="/ents/eventlist/specialevents/">Special Event</a>
						                 | 
                                            <a href="/ents/eventlist/summerball/">Summer Ball</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item23 itemOdd msl-brand-sinsavers" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/540/"><span class="msl_event_image"><img src="/asset/Event/6050/527647_10150874850848579_1378156209_n.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/540/" class="msl_event_name">sinsavers</a>
                                </dt>
                                <dd class="msl_event_time">6th June 10pm - 2:30am</dd>
                                <dd class="msl_event_location">Sin CIty</dd>

				                <dd class="msl_event_description">The only night in Swansea with censored drinks prices and an anything goes attitude.</dd>
                                <dd class="msl_event_brand">sinsavers</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item24 itemEven msl-brand-tooters" data-msl-organisation-id="8387">

			                <dl>
				                <dt>
                                    <a href="../ents/event/364/"></a>
                                    <span class="msl_event_organisation">Divas</span>
                                    <a href="/ents/event/364/" class="msl_event_name">tooters</a>
                                </dt>
                                <dd class="msl_event_time">7th June 9pm - 2am</dd>
                                <dd class="msl_event_location">Divas</dd>

				                <dd class="msl_event_description">2 Drinks for �2 - 2 Rooms - 2 DJ's - 2 Many Stories</dd>
                                <dd class="msl_event_brand">tooters</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
</div>
</div>

</div>

<!-- -->
<div id="newsmain" class="news_1col news_full" style="display: none;">

	<div id="ctl00_news_rptNews_ctl00_divItem" class="item1 news_item itemOdd mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl00_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>You may be eligible for a refund on your TVLicense</h5>
			<p class="msl_pubdate">Wed 22 May 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl00_lnkImage" href="../news/article/susu/You-may-be-eligible-for-a-refund-on-your-TV-License/"><img src="/asset/News/6013/tv-license.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl00_imgImage" alt=""></a></span>
			<p class="leader">TV Licensing launches refund campaign for students moving home for the summer months</p>
             
            

			<div id="ctl00_news_rptNews_ctl00_pnlArticleText" class="msl_newsbodytext">
	<p>
 As students in Swansea University prepare for their exams, TV Licensing is reminding those moving home for the summer they might be able to claim a refund on their TV Licence, worth �36.37.</p>
<p>
 To be eligible, students need to have a TV Licence, be leaving their halls or rented accommodation in Swansea and moving back home to a licensed address.</p>
<p>
 Any finance-savvy student who purchased a TV Licence at the start of the academic year will have a full three months remaining on their licence. This means they can now claim a refund for the final unused quarter. The savings could pay for a ticket to a gig, a one-way flight to Amsterdam or night out to celebrate the end of student exams.</p>
<p>
 Sara Jones, spokesperson for TV Licensing in Wales,said:</p>
<p>
 �With exams fast approaching and the Easter term coming to an end, the student refund is fantastic news for students who planned ahead and bought their licence at the start of the academic year. It�s vital students understand the law when it comes to watching or streaming live TV or they risk prosecution and fine of up to �1,000.�</p>
<p>
 Recent research* by TV Licensing shows three out of five students watch at least an hour of TV a day, and 71 per cent of students use their laptop to watch TV. A TV Licence is needed to watch, record or stream programmes at the same time as they are shown on TV. This is the case whether you use a TV, laptop, games console, tablet, mobile phone, or any other device.</p>
<p>
 Phil Davis, Chair of the National Association of Student Money Advisers (NASMA), added:</p>
<p>
 �The summer is a great opportunity for students to repair their bank balances, and it�s important they use every opportunity to do so. Getting a refund on the unused three months of a TV Licence is a really easy step to take. </p>
<p>
 �It�s important students buy a TV licence at the earliest opportunity when starting university and take advantage of the flexible payment options available to them. Most of all, it�s vital students avoid fines for not holding aTV Licence � a quick visit to<a href="http://www.tvlicensing.co.uk/studentinfo">www.tvlicensing.co.uk/studentinfo</a>helps students ensure they are covered to watch TV on a range of devices.�</p>
<p>
 To arrange a refund, or for further information, simply visit:<a href="http://www.tvlicensing.co.uk/studentinfo">www.tvlicensing.co.uk/studentinfo</a>, or call TV Licensing on 0300 790 6090.</p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl01_divItem" class="item2 news_item itemEven mslorg6013 msltagleader-sport">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl01_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Varsity students advised to staysafe</h5>
			<p class="msl_pubdate">Tue 23 Apr 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl01_lnkImage" href="../news/article/susu/Varsity-students-advised-to-stay-safe/"><img src="/asset/News/6013/crowd-shot.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl01_imgImage" alt=""></a></span>
			<p class="leader">The Welsh Ambulance Service are encouraging students to stay safe</p>
             
            

			<div id="ctl00_news_rptNews_ctl01_pnlArticleText" class="msl_newsbodytext">
	<p>
 The Welsh Ambulance Service (WAS) is encouraging students to stay safe and plan ahead as they gear up for this coming Wednesday�s annual Varsity sports day in Cardiff city centre.</p>
<p>
 With over 20 sporting events taking place across the city, culminating in the Cardiff v Swansea students Varsity rugby match at the Millennium Stadium, the day is expected to be a busy one for the capital.</p>
<p>
 Additional services are being put in place to prepare for an anticipated increase in emergency calls to ensure the ambulance service can concentrate on reaching those patients with serious or immediately life threatening illnesses or injuries.</p>
<p>
 The ambulance service�s mobile treatment centre on St Mary�s Street, supported by St John Wales volunteers, will be open to primarily treat walk-in patients and minor injuries.</p>
<p>
 Cardiff�s Alcohol Treatment Centre based at Ebenezer Chapel on Charles Street will also be open. The triage project, a joint venture between Cardiff and Vale of Glamorgan councils and Cardiff and Vale University Health Board and supported by WAS and South Wales Police, treats casualties and provides an alcohol recovery service to ensure the safety of patients who have overindulged.</p>
<p>
 Bob Tooby, the Welsh Ambulance Service�s Head of Service for Cardiff and the Vale said: �We do anticipate an increase in calls associated with the Varsity sports day. There can be a tendency for students to overindulge in alcohol and become unwell and although we don�t want to be killjoys, we do ask students to act responsibly and look after their friends and colleagues.</p>
<p>
 �Please think in advance about the consequences of day and night drinking, make sure you have planned how you are getting home and bear in mind that it often gets much colder late at night.</p>
<p>
 �The ambulance service and emergency departments are for emergencies only. Please <em>�Choose Well�</em> and remember that pharmacies, GPs Out of Hours, NHS Direct Wales and self help are all alternatives to dialling 999.</p>
<p>
 �Unfortunately over indulgence can also mean an increase in abuse of our staff so please remember to treat our staff just as you would wish them to treat you.�</p>
<p>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl02_divItem" class="item3 news_item itemOdd mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl02_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Important Graduation gown notice.</h5>
			<p class="msl_pubdate">Mon 22 Apr 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl02_lnkImage" href="../news/article/susu/Important-Graduation-gown-notice/"><img src="/asset/News/6013/Graduation.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl02_imgImage" alt=""></a></span>
			<p class="leader">If you are thinking of purchasing a gown with 'Get Down and Graduate' please read.</p>
             
            

			<div id="ctl00_news_rptNews_ctl02_pnlArticleText" class="msl_newsbodytext">
	<p>
 Are you graduating this year? Then, please take two minutes to read this important bulletin on graduation gowns.</p>
<p>
 If you have heard or used the company �Get Gown and Graduate� then please be warned that they are not currently approved by the University due to the uncertainty of whether they are selling the correct regulation ceremonial gowns for Swansea University.</p>
<p>
 The University have issued warnings on their website stating that if you are not in the correct regulation gowns, you will not be allowed to attend the graduation ceremony; even if you turn up on the day in these robes, until they have been approved by the University.</p>
<p>
 The University and Students� Union are doing research into this company and their gowns; once this is complete there will be an announcement.</p>
<p>
 Thank you for reading and happy graduation.</p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl03_divItem" class="item4 news_item itemEven mslorg11165">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl03_pnlOrgName" class="msl_news_org">
	
                Marvel
            
</div>
			<h5>Marvel Society First Meeting</h5>
			<p class="msl_pubdate">Thu 18 Apr 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl03_lnkImage" href="../news/article/marvelsociety101/Marvel-Society-First-Meeting/"><img src="/asset/Organisation/11165/marvel logo.png?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl03_imgImage" alt=""></a></span>
			<p class="leader"></p>
             
            

			<div id="ctl00_news_rptNews_ctl03_pnlArticleText" class="msl_newsbodytext">
	<p>
 <span class="messageBody"><span class="userContent">Hello welcome to the Marvel Society here at Swansea University. A place to meet people who share a passion for the Marvel world. We will be doing a great number of things such as watching films, indulging in comics, attending cosplay events, debates and much, much more. (dress up in optional) We are a friendly bunch who are looking forward to meeting new people with similar interests and we hope you feel the same. If this society interests you and you would consider joining in the new academic year then please come to on Wednesday 1st May at 6.00pm for snacks and goodies where we will be voting our first official committee. Please come and support us for with great power comes great responsibility.</span></span><br>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl04_divItem" class="item5 news_item itemOdd mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl04_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Run to be a part-timeofficer</h5>
			<p class="msl_pubdate">Thu 18 Apr 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl04_lnkImage" href="../news/article/susu/Run-to-be-a-part-time-officer/"><img src="/asset/News/6013/pto-web-ad.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl04_imgImage" alt=""></a></span>
			<p class="leader">Become an officer and boost your skills.</p>
             
            

			<div id="ctl00_news_rptNews_ctl04_pnlArticleText" class="msl_newsbodytext">
	<div>
 <p>
  <strong>Do you want to gain invaulable experience working as a part-time officer for the Union?</strong></p>
 <p>
  Part-time officers are a voluntary elected position in the Union. Officers are elected to represent students and run campaigns on the issues that matter to them. Its a great experience and will allow you to really improve students lives whilst increasing your own employability!</p>
 <p>
  </p>
 <p>
  <strong>OFFICIAL NOTICE OF POLL � PART-TIME OFFICER ELECTIONS</strong></p>
</div>
<p>
 Notice is hereby given of an Election to elect 11 Part-time Officers for the academic year 2013-2014. The positions are :-</p>
<p>
 </p>
<p>
 <strong>COMMUNITY &amp; HOUSING OFFICER </strong></p>
<p>
 <strong>ENVIRONMENT OFFICER</strong></p>
<p>
 <strong>ETHICS OFFICER</strong></p>
<p>
 <strong>GENERAL SECRETARY </strong></p>
<p>
 <strong>PART-TIME OFFICER </strong></p>
<p>
 <strong>MATURE STUDENTS OFFICER</strong></p>
<p>
 <strong>SWYDDOG MATERION CYMRAEG (WELSH AFFAIRS OFFICER)</strong></p>
<p>
 </p>
<p>
 <strong><u>LIBERATION POSITIONS:</u></strong></p>
<p>
 <strong>BLACK STUDENTS OFFICER</strong></p>
<p>
 <strong>LGBT OFFICER (OPEN PLACE)</strong></p>
<p>
 <strong>LGBT OFFICER (WOMEN�S PLACE)</strong></p>
<p>
 <strong>STUDENTS WITH DISABILITIES OFFICER</strong></p>
<p>
 </p>
<p>
 Nominations will open on <strong>TUESDAY, 23<sup>RD</sup> APRIL 2013 at 12 noon.</strong></p>
<p>
 Nominations will close on <strong>TUESDAY, 30<sup>TH</sup> APRIL 2013 at 5.00 p.m.</strong></p>
<p>
 <strong><em>Candidates can nominate themselves on-line from midday on the 23<sup>rd</sup> April 2013 at </em></strong><a href="http://www.swansea-union.co.uk/"><strong><em>www.swansea-union.co.uk</em></strong></a><strong><em> please follow the links for the nomination process.</em></strong></p>
<p>
 Publicity deadline is <strong>WEDNESDAY, 1<sup>ST</sup> MAY 2013 AT 4.00 p.m.</strong></p>
<p>
 There will be a meeting with the Returning Officers on <strong>TUESDAY, 30<sup>TH</sup> APRIL 2013 at 5.00 p.m. <u>Could candidates please make every effort to attend.</u></strong></p>
<p>
 <strong>Voting will take place via an on-line portal at </strong><a href="http://www.swansea-union.co.uk/"><strong>www.swansea-union.co.uk</strong></a> <strong>on Tuesday, 7<sup>th</sup> May 2013 between 8 a.m. and 8 p.m.</strong></p>
<p>
 <strong>Election results will be announced the same evening.</strong></p>
<p>
 <strong>*More details are available from </strong><a href="mailto:administrator"swansea-union.co.uk@><strong>administrator@swansea-union.co.uk</strong></a><strong> or </strong><a href="mailto:matthewhurst"swansea-union.co.uk@><strong>matthewhurst@swansea-union.co.uk</strong></a></p>
<p>
 </p>
<p>
 <strong> Stuart Rice Shona Vrac-Lee / Matt Hurst</strong></p>
<p>
 <strong> <u>DEPUTY RETURNING</u> <u>ASSISTANT RETURNING</u></strong></p>
<p>
 <strong> <u>OFFICER.</u> <u>OFFICERS.</u></strong></p>
<p>
 </p>
<p>
 </p>
<div>
 <p>
  <strong>HYSBYSIAD SWYDDOGOL YNGLYN � PHLEIDLEISIO � ETHOLIADAU SWYDDOGION RHAN-AMSER</strong></p>
</div>
<p>
 Rhodir hysbysiad yma am y bleidlais i ethol 11 Swyddog Rhan-Amser ar gyfer blwyddyn academaidd 2013-2014. Y safleoedd yw:-</p>
<p>
 </p>
<p>
 <strong>SWYDDOG CYMUNED A TAI </strong></p>
<p>
 <strong>SWYDDOG YR AMGYLCHEDD </strong></p>
<p>
 <strong>SWYDDOG MOESEG</strong></p>
<p>
 <strong>YSGRIFENNYDD CYFFREDINNOL </strong></p>
<p>
 <strong>SWYDDOG RHAN-AMSER </strong></p>
<p>
 <strong>SWYDDOG MYFYRWYR HYN</strong></p>
<p>
 <strong>SWYDDOG MATERION CYMRAEG (WELSH AFFAIRS OFFICER)</strong></p>
<p>
 </p>
<p>
 <strong><u>SAFLEOEDD RHYDDHAD:</u></strong></p>
<p>
 <strong>SWYDDOG MYFYRWYR DU</strong></p>
<p>
 <strong>SWYDDOG LHBT (LLE AGORED)</strong></p>
<p>
 <strong>SWYDDOG LHBT (LLE MENYWOD)</strong></p>
<p>
 <strong>SWYDDOG MYFYRWYR AG ANABLEDD</strong></p>
<p>
 </p>
<p>
 Bydd enwebiadau yn agor ar <strong>Ddydd Mawrth 23<sup>ains</sup> o Ebrill 2013, am 12 ganol dydd.</strong></p>
<p>
 Bydd enwebiadau yn cau <strong>Ddydd Mawrth, 30<sup>ain</sup> o Ebrill 2013 am 5.00 y.p.</strong></p>
<p>
 <strong><em>Gall ymgeisiwyr enwebu eu hunain ar-lein o ganol dydd ar y 23<sup>ain</sup> o Ebrill 2013 ar wefan </em></strong><a href="http://www.swansea-union.co.uk/"><strong><em>www.swansea-union.co.uk</em></strong></a><strong><em> dilynwch y linc os gwelwch yn dda ar gyfer y broses enwebu.</em></strong></p>
<p>
 Terfyn Amser y Cyhoeddusrwydd ydy <strong>Dydd Mercher, Mai 1<sup>af</sup> 2013 am 4:00y.p.</strong></p>
<p>
 Bydd yna gyfarfod gyda�r Swyddogion Adroddol ar <strong>Ddydd Mawrth 30<sup>ain</sup> o Ebrill 2013 am 5:00 y.p. <u>Gall ymgeiswyr wneud pob ymdrech i fynychu. </u></strong></p>
<p>
 <strong>Bydd Pleidleisio yn digwydd ar-lein ar wefan </strong><a href="http://www.swansea-union.co.uk/"><strong>www.swansea-union.co.uk</strong></a><strong> ar Ddydd Mawrth, </strong>7<sup>fed</sup><strong> o Fai 2013 rhwng 8 y.b. and 8 y.p.</strong></p>
<p>
 <strong>Bydd canlyniadau�r etholiad yn cael eu cyhoeddi yr un noswaith. </strong></p>
<p>
 <strong>*Mwy o fanylion ar gael trwy </strong><a href="mailto:administrator"swansea-union.co.uk@><strong>administrator@swansea-union.co.uk</strong></a><strong> neu </strong><a href="mailto:matthewhurst"swansea-union.co.uk@><strong>matthewhurst@swansea-union.co.uk</strong></a></p>
<p>
 </p>
<p>
 <strong> Stuart Rice Shona Vrac-Lee / Matt Hurst</strong></p>
<p>
 <strong> <u>Is-Adroddwr</u>   <u>Adroddwyr Cynorthwyol</u></strong></p>
<p align="center">
 </p>
<p align="center">
 </p>
<p align="center">
 </p>
<p align="center">
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl05_divItem" class="item6 news_item itemEven mslorg6013 msltagleader- union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl05_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Statement on Student Loans</h5>
			<p class="msl_pubdate">Wed 17 Apr 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl05_lnkImage" href="../news/article/susu/Statement-on-Student-Loans/"><img src="/asset/News/6013/piggy-website-540x238-q40.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl05_imgImage" alt=""></a></span>
			<p class="leader">The Students� Union has been investigating why students will receive their loans and grants one week after the start of the final term.</p>
             
            

			<div id="ctl00_news_rptNews_ctl05_pnlArticleText" class="msl_newsbodytext">
	<p>
 The Students� Union has been investigating why students will receive their loans and grants one week after the start of the final term.</p>
<p>
 <strong>In a response to the Education Officer, Mr Raymond Ciborowski, Registrar and Chief Operating Officer said:</strong></p>
<p>
 In a departure from the practice in previous years, the SLC required information from the University on the term dates applicable for AY 12/13 in November 2011 (rather than in early 2012).</p>
<p>
 The date that was supplied to the SLC for the start of the Summer Term was 22/04/13. It was understood that this date had been formally confirmed.</p>
<p>
 In January, however, the Summer Term start date for 2012 was finally set as 15/04/13.</p>
<p>
 The University did not inform the SLC of this discrepancy in the dates.</p>
<p>
 Students were informed individually by the SLC at the start of the academic year that the payment date for loans/grants for the Summer Term would be 22/04/13.</p>
<p>
 In March the University became aware of the discrepancy between the payment date and the start of term date and emailed all affected students before the Easter Vacation alerting them to the payment date of 22/04/13, and making students aware of how to access Money Advice if they were going to experience financial difficulties.</p>
<p>
 I can only apologise if this has caused any confusion for students who would have expected the payment date, as normal, to coincide with the date of the start of term.</p>
<p>
 I understand a number of students have been in contact with Money Advice for support.</p>
<p>
 <strong>Zahid Raja, Education Officer said:</strong><br>
 <br>
 I welcome the clarity in the response from the University. However, for many, this administrative error has caused much distress. For those who believe that they have incurred bank charges as a result of the error, it is recommended that you contact Raymond directly: <a href="mailto:Raymond.Ciborowski"swansea.ac.uk@>Raymond.Ciborowski@swansea.ac.uk</a><br>
 <br>
 If you need help with this, please get in touch with the Students� Union Advice Centre who offer independent advice on such issues: <a href="http://www.swansea-union.co.uk/advice/advicecentre/">http://www.swansea-union.co.uk/advice/advicecentre/</a></p>
<p>
 If you�re struggling to make ends meet whilst you�re waiting for your loan / grant, please contact the Swansea University Money Advice Service who can help you access the financial contingency fund: Email Address: <a href="mailto:MoneyDoctors"swansea.ac.uk@>MoneyDoctors@swansea.ac.uk</a> Phone Number: 01792 606 699</p>
<p>
 <br>
 <br>
 <br>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl06_divItem" class="item7 news_item itemOdd mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl06_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>The Big Awards Party ishere</h5>
			<p class="msl_pubdate">Fri 22 Mar 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl06_lnkImage" href="../news/article/susu/The-Big-Awards-Party-is-here/"><img src="/asset/News/6013/su-awards.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl06_imgImage" alt=""></a></span>
			<p class="leader">Nominations are now open for this year's SU Awards</p>
             
            

			<div id="ctl00_news_rptNews_ctl06_pnlArticleText" class="msl_newsbodytext">
	<p>
 The SU Awards are back and bigger than ever, so if you know someone you think deserves to win an award nominate them online.</p>
<p>
 This year's Big Awards Party will be recognsing students, clubs and societies who have dedicated time and energy to the Students' Union, helping to improve student's lives on campus.</p>
<p>
 The awards will be taking place on campus on the 5th June, tickets go on sale after Easter. Nominations close on the 15th May.</p>
<p>
 To make a nomination please click <a href="https://docs.google.com/forms/d/1eLQi1L6ueL33uM17R4VeCZVsJdtjXFYBIK2g5tzN_Sg/viewform">here.</a></p>
<p>
 <a href="/asset/News/6013/SU-Awards-2013_categorycriteria.pdf">Categories and criteria. </a></p>
<p>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl07_divItem" class="item8 news_item itemEven mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl07_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Swansea celebrates awards success</h5>
			<p class="msl_pubdate">Fri 15 Mar 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl07_lnkImage" href="../news/article/susu/Swansea-celebrates-awards-success/"><img src="/asset/News/6013/Awards.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl07_imgImage" alt=""></a></span>
			<p class="leader">The Students' Union has won five NUS Wales Awards</p>
             
            

			<div id="ctl00_news_rptNews_ctl07_pnlArticleText" class="msl_newsbodytext">
	<p>
 Swansea University Students� Union are celebrating after being named Higher Education Students� Union of the year at the NUS Wales Awards on Wednesday night.</p>
<p>
 Alongside this success the Union also won four awards in other categories at the event, including a Community Relations award for all the hard work we have been doing to integrate students in to the local community and help keep making Swansea a great place to live. The Union had a total of eight nominations in six categories, coming out on top for prizes on the night.</p>
<p>
 The winning prizes also included, Higher Education Officer of the year for International Officer Mahaboob Basha, Society of the Year won by Choral Society and Best Student Journalist picked up by Chris Flynn.</p>
<p>
 President Tom Upton said �Being up for nomination in so many categories at the awards this year was really exciting but to have been winners in nearly all of the categories was completely unexpected.</p>
<p>
 �Our staff, officers and students do so much to make Swansea Union brilliant and it all paid off on Wednesday night.�</p>
<p>
 The Union has worked hard over the last year to improve student feedback implementing a number of new forums and rep systems and has campaigned to improve represntation for students at the university, efforts which have nowbeen recognised at a national level.</p>
<p>
 Swansea students other nominations included Human Rights Action Society, The Siren for student media and Samantha Booth for student journalist of the year. </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl08_divItem" class="item9 news_item itemOdd mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl08_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Meet your new team</h5>
			<p class="msl_pubdate">Mon 11 Mar 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl08_lnkImage" href="../news/article/susu/Meet-your-new-team/"><img src="/asset/News/6013/new-team-photo.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl08_imgImage" alt=""></a></span>
			<p class="leader">A new team of seven officers will be representing you next year.</p>
             
            

			<div id="ctl00_news_rptNews_ctl08_pnlArticleText" class="msl_newsbodytext">
	<p>
 After a gruelling week of campaigning seven students have been elected to represent you at University next year.</p>
<p>
 A new team of Full-time Officers will be starting from July 1st and their role will be to ensure you get the best experience at Swansea University as possible.</p>
<p>
 Even if you don't get involved in the Union, officers play a huge part in your University, standing up for students needs, ensuring the University are representing you and even simply making uni fun.</p>
<p>
 The Union broke their voting record for the second year in a row with 3,286 students casting their votes.</p>
<p>
 The list of elected officers are:</p>
<p>
 President- Zahid Raja</p>
<p>
 Education Officer- Swaran Singh</p>
<p>
 Societies and Services Officer- Ceinwen Cloney</p>
<p>
 Sports Officer- Charlotte Peters</p>
<p>
 Welfare Officer- Becky Grimes</p>
<p>
 Women's Officer- Rosie Inman</p>
<p>
 International Officer- Eva Donoghue</p>
<p>
 Look out for them on campus and don't forget to say hello next year!</p>
<p>
 </p>
<p>
 *Photograph courtesy of Jon May photography</p>
<p>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl09_divItem" class="item10 news_item itemEven mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl09_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Volunteer as a Green ImpactAuditor</h5>
			<p class="msl_pubdate">Fri 01 Mar 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl09_lnkImage" href="../news/article/susu/Volunteer-as-a-Green-Impact-Auditor/"><img src="/asset/News/6013/Green_Impact_uni.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl09_imgImage" alt=""></a></span>
			<p class="leader">Are you free on the 22nd March? Would you like something fantastic to put on your CV?</p>
             
            

			<div id="ctl00_news_rptNews_ctl09_pnlArticleText" class="msl_newsbodytext">
	<p>
 Volunteer as a Green Impact Auditor/ Gwirfoddoli fel Archwiliwr Effaith Gwyrdd</p>
<p>
 Are you free on the 22<sup>nd</sup> March? Would you like something fantastic to put on your CV?</p>
<p>
 The Students� Union are looking for studentvolunteersto help out with the Green Impact staff audit. Green Impact is an award that Students� Unions and Universities can work towards to get recognition of their environmentally friendly credentials.</p>
<p>
 Throughout the past year, teams of staff across the campus have beencompleting'green' tasks to createpositiveenvironmental changes in their departments. However, before staff can berecognisedandawardedthey must be audited to the national standard � their awards are in your hands!</p>
<p>
 As avolunteer you will be required to undergo a morning training session where you will be trained by a National Union of Students Green Impactstaff member. After your delicious free lunch you will then head out and complete the audits of departments.</p>
<p>
 This scheme is a great opportunity to gain some important employability skills and experience, and also earn points if you are part of the Employability Awards <a href="http://www.swan.ac.uk/employability-awards/">http://www.swan.ac.uk/employability-awards/</a>.</p>
<p>
 If you�re interested, let us know ASAP to secure your place. Last year we had over 200 applicants!</p>
<p>
 To apply please email <a href="mailto:volunteering"studentswansea.co.uk@>volunteering@studentswansea.co.uk</a> with the following information:</p>
<p>
 </p>
<p>
 Name<br>
 Student Number<br>
 Level of study<br>
 Subject<br>
 Department<br>
 Dietary Requirements<br>
 Access requirements</p>
<p>
 </p>
<p>
 </p>
<p>
 Gwirfoddoli fel Archwiliwr Effaith Gwyrdd</p>
<p>
 A ydych yn rhydd ar y 22ain o Fawrth? A hoffech gael rhywbeth ffantastig i roi ar eich CV?</p>
<p>
 Mae�r Undeb Myfyrwyr yn edrych am fyfyrwyr i wirfoddoli i helpu allan gyda�r archwiliad Effaith Gwyrdd staff. Mae Effaith Gwyrdd yn wobr y gall yr Undeb a�r Brifysgol gweithio tuag at i gael cydnabyddiaeth am eu cymwysterau amgylcheddol cyfeillgar.</p>
<p>
 Trwy gydol y flwyddyn ddiwethaf, mae timau o staff ar draws y campws wedi bod yn cwblhau tasgau �gwyrdd� er mwyn creu newidiadau amgylcheddol cadarnhaol yn eu hadrannau. Er hynny, cyn y gall staff cael eu cydnabyddi a�u gwobrwyo mae�n rhaid iddynt gael ei archwilio i safon genedlaethol - mae eu gwobrwyon yn eich dwylo!</p>
<p>
 Fel gwirfoddolwr, byddwch yn cael eich gofyn i fynychu bore hyfforddiant lle byddwch yn cael eu hyfforddi gan aelod o staff Effaith Gwyrdd yr Undeb Genedlaethol Myfyrwyr. Ar �l i�ch cinio blasus rhad ac am ddim, byddwch wedyn yn mynd allan a chwblhau archwiliadau o�r adrannau.</p>
<p>
 Mae�r cynllun hwn yn gyfle gwych i ennill rhai sgiliau a phrofiad cyflogadwyedd pwysig, a hefyd ennill pwyntiau os ydych yn rhan o�r Gwobrau Cyflogadwyedd <u>&lt;<a href="http://www.swan.ac.uk/employability-awards/">http://www.swan.ac.uk/employability-awards/</a>&gt;</u>.</p>
<p>
 Os oes gennych ddiddordeb, gadewch i ni wybod cyn gynted � phosibl i sicrhau eich lle. Llynedd roedd gennym dros 200 o ymgeiswyr!</p>
<p>
 I wneud cais anfonwch e-bost i <a href="mailto:volunteering"studentswansea.co.uk@>volunteering@studentswansea.co.uk</a> gyda�r wybodaeth ganlynol:</p>
<p>
 </p>
<p>
 Enw<br>
 Rhif Myfyriwr<br>
 Lefel Astudio<br>
 Pwnc<br>
 Adran<br>
 Gofynion Dietegol<br>
 Gofynion Mynediad</p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl10_divItem" class="item11 news_item itemOdd mslorg7362">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl10_pnlOrgName" class="msl_news_org">
	
                Volleyball
            
</div>
			<h5>Ladies hold their nerve atsemifinals</h5>
			<p class="msl_pubdate">Tue 26 Feb 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl10_lnkImage" href="../news/article/volleyball/Ladies-hold-their-nerve-at-semifinals/"><img src="/asset/Organisation/7362/Club photo.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl10_imgImage" alt=""></a></span>
			<p class="leader">The ladies beat Southampton Solent to make the Cup Final 2013.</p>
             
            

			<div id="ctl00_news_rptNews_ctl10_pnlArticleText" class="msl_newsbodytext">
	<p>
	Bright and early on Sunday morning the ladies' volleyball team left Swansea and headed to Southampton to take on Southampton Solent in the Western Conference Cup semifinal.</p>
<p>
	Being the only team that Swansea has lost to this season, there were mixed feelings about having to take them on again; On the one hand fearing they might lose and miss out on the Cup final, on the other hand hoping to revenge themselves for the close loss in December.</p>
<p>
	The game started promisingly, a few well-placed short balls quickly giving them a 5:1 headstart. This lead was soon extended to 6 points and could be held for most of the set, thanks to the team's very concentrated &amp; structured play. Only at the end did Southampton Solent catch up a little, but the set finally went to Seansea 25:22.</p>
<p>
	In their previous performance against Southampton Solent they had started similarly, winning the 1st set, but then they had got off to a bad start in the 2nd and 3rd resulting in the match being lost.</p>
<p>
	So the team was determind not to repeat this mistake and started well this time. Neither team could get any significant advantage over the other at first - both level at 9:9. Then Swansea turned up a gear and started to pull away. From 14:10 to 18:10, the victory seemed certain. But Southampton Solent were not going to give up without a fight and came back strongly to draw level at 23:23.</p>
<p>
	At the crucial moment Swansea managed to regain their composure, showig nerves of steel to win the next two points and claiming their place in the cup final on 13th March.</p>
<p>
	</p>
<p>
	</p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl11_divItem" class="item12 news_item itemEven mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl11_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>The Union's affiliations explained</h5>
			<p class="msl_pubdate">Tue 26 Feb 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl11_lnkImage" href="../news/article/susu/The-Unions-affiliations-explained/"><img src="/asset/News/6013/affiliations.gif?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl11_imgImage" alt=""></a></span>
			<p class="leader">Every year students vote on our affiliations, but what does it all mean?</p>
             
            

			<div id="ctl00_news_rptNews_ctl11_pnlArticleText" class="msl_newsbodytext">
	<p>
 Alongside the Full-time Officer election next week the Union will also be asking all students to decide who we affiliate to.</p>
<p>
 The Union currently affiliates to a number of groups which provide support and help on important issues. All members have the chance to vote and decide where we spend your money. If you've ever wondered what they all mean on your ballot paper then read on:</p>
<p>
 <strong>NUS (National Union of Students):- �30,359</strong></p>
<p>
 The National Union of students is the national body of Students� Unions which represents students at a Wales as well at UK level, NUS provides training, help and support to both officers, students and staff within in Unions.NUS supports student rights andcampaigns to improve student experience.It also provides the NUS Extra Card.</p>
<p>
 For more information; <a href="http://www.nus.org.uk/">www.nus.org.uk</a></p>
<p>
 <strong>Advice UK: - �769</strong></p>
<p>
 Advice UK is the largest support network for Advice and Advice centres in the UK, it helps its members with help and support, insurance and guidance for workers in Advice Centres across the country.</p>
<p>
 For more information; <a href="http://www.adviceuk.org.uk/">www.adviceuk.org.uk</a></p>
<p>
 <strong>N.A.C.A.B: - (National Association of Citizens Advice Bureaux):- �864</strong></p>
<p>
 N.A.C.A.B provides advice and supports the Union�s Advice Centre, a national organisation that helped over 2 million people in the last year. The N.A.C.A.B is part of Citizens Advice.</p>
<p>
 For more information; <a href="http://www.citizensadvice.org.uk/">www.citizensadvice.org.uk</a></p>
<p>
 <strong>U.K.C.I.S.A. (United Kingdom Council for International Student Affairs) �357</strong></p>
<p>
 The UKCISA is the UK�s National advisory body that supports and serves the interests of International Students and those who work with them. The guidance and support from the UKCISA supports the Advice Centre as well as the International Officer in their roles.</p>
<p>
 For more information; <a href="http://www.ukcisa.org.uk/">www.ukcisa.org.uk</a></p>
<p>
 <br clear="all">
 <strong>S.R.A (Student Radio Association) �84</strong></p>
<p>
 The student radio association acts as the support body for student radio in the UK, the body encourages good practice and networking between stations as well as support and guidance.</p>
<p>
 For more information; <a href="http://www.studentradio.org.uk/">www.studentradio.org.uk</a></p>
<p>
 <strong>N.D.N.A. (National Day Nurseries Association) �145</strong></p>
<p>
 The NDNA is the national charity representing Children�s day nurseries across the UK, they provide information, training and support so that the Union can deliver quality care to young children.</p>
<p>
 For more information; <a href="http://www.ndna.org.uk/">www.ndna.org.uk</a></p>
<p>
 </p>
<p>
 <strong><u>The voting for this election will be held on the 5<sup>th, </sup>6<sup>th</sup> and 7<sup>th</sup> of March 8am � 8pm<br>
 <br>
 Results will be declared the following day</u></strong></p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl12_divItem" class="item13 news_item itemOdd mslorg6013 msltagleader-sport msltaggreen">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl12_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Well deserved victory for the EquestrianClub</h5>
			<p class="msl_pubdate">Thu 14 Feb 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl12_lnkImage" href="../news/article/susu/Well-deserved-victory-for-the-Equestrian-Club/"><img src="/asset/News/6013/First-Team-Away-at-Cardiff.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl12_imgImage" alt=""></a></span>
			<p class="leader">The First Team for Swansea University Equestrian Club finished first place in their away competition at Aberystwyth this week.</p>
             
            

			<div id="ctl00_news_rptNews_ctl12_pnlArticleText" class="msl_newsbodytext">
	<p>
 The First Team for Swansea University Equestrian Club finished first place in their away competition at Aberystwyth this week.</p>
<p>
 Despite not knowing the competition ground and riding unfamiliar horses the team were able grab a well deserved win.</p>
<p>
 The first team consisting of, Simon Leng, Jess Hassell, Ben Fitzpatrick and Rosie Wilson went in to the competition virtually on a level pegging with Aberystwyth whilst Cardiff were out in front.</p>
<p>
 After the first dressage phase had been completed the Swansea team found they had slipped quite a few points behind the leaders with the Show Jumping Round still ahead.Simon Leng, Captain of the First team said �Naturally going into the show jumping phase we weren't overly confident but gave it our best shot�.</p>
<p>
 The team�s hard work paid off and a successful round with nearly all the riders having a clear round�s jumping saw Swansea win their final away competition.</p>
<p>
 The team scores were incredibly close, with Swansea on 58 penalties, Cardiff on 61 and Aberystwyth on 64.</p>
<p>
 If you�d like to find out more about joining the club all the information can be found <a href="http://www.swansea-union.co.uk/activities/Equestrian/">here</a>.</p>
<p>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl13_divItem" class="item14 news_item itemEven mslorg6013 msltagswansea university msltagswansea university students union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl13_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Union wins campaign to end evening &amp; Wednesday afternoonlectures</h5>
			<p class="msl_pubdate">Wed 13 Feb 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl13_lnkImage" href="../news/article/susu/Union-wins-campaign-to-end-evening-amp-Wednesday-afternoon-lectures/"><img src="/asset/News/6013/wedidit.png?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl13_imgImage" alt=""></a></span>
			<p class="leader">Students� Union wins campaign to end evening &amp; Wednesday afternoon lectures for 2013/14</p>
             
            

			<div id="ctl00_news_rptNews_ctl13_pnlArticleText" class="msl_newsbodytext">
	<p>
	The Students� Union has won a campaign to end evening &amp; Wednesday afternoon lectures for 2013/14.<br>
	<br>
	In October, a motion was put forward to the Student Forum asking the Students� Union to end evening and Wednesday afternoon lectures (<a href="/asset/News/6013/keepwedfree-nolecafter5-motion.pdf">click here to see the motion</a>)<br>
	<br>
	Today, in a statement to the Education Officer, the University Senior Management Team told the Students� Union that they had a full debate about the issues and that there was overwhelming support for the Students� Union position.</p>
<h3>
	<strong>Headline changes for the next academic year - 2013/14:</strong></h3>
<ul>
	<li>
		<strong>On Mondays, Tuesdays, Thursdays and Fridays - the University teaching hours will now be restricted to 9am-6pm.</strong><br>
		</li>
	<li>
		<strong>On Wednesdays the University teaching hours will now be restricted to 9am-1pm.</strong><br>
		</li>
	<li>
		<strong>If a lecture is rescheduled due to an emergency, it must be ensured that the lecture is fully available in video format on blackboard for those students who have commitments outside of the official University teaching hours.</strong></li>
</ul>
<p>
	</p>
<h4>
	<strong>The Students� Union Education Officer who led the campaign, said:</strong></h4>
<p>
	<br>
	�We lobbied many individuals across the University to get this result. Our message has always been clear: for a lot of students, the full Student Experience isn�t just limited to what happens in the classroom but also what happens outside of it. Today, the Vice Chancellor and his team listened to our position and recognised that our arguments were valid ones.<br>
	<br>
	A lot of work has gone on behind the scenes including a full timetabling and spacing review by estates looking at how rooms are currently used in the University � so thanks to all of the individuals involved with delivering this outcome.<br>
	<br>
	Whilst we would like to see lectures end at 5pm, we understand that there are spacing issues to consider. For next year, 6pm is a reasonable compromise from some lectures currently ending at 7pm.<br>
	<br>
	We also have a good number of students who are parents or have other caring responsibilities � this is a great step forward in meeting the needs of such students who are often forgotten about.�</p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl14_divItem" class="item15 news_item itemOdd mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl14_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Support Eating Disorder AwarenessWeek</h5>
			<p class="msl_pubdate">Wed 13 Feb 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl14_lnkImage" href="../news/article/susu/Support-Eating-Disorder-Awareness-Week/"><img src="/asset/News/6013/project_image.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl14_imgImage" alt=""></a></span>
			<p class="leader">This we we're raising awareness around eating disorders.</p>
             
            

			<div id="ctl00_news_rptNews_ctl14_pnlArticleText" class="msl_newsbodytext">
	<p>
 This week is Eating disorder awareness week, the 11<sup>th</sup> � 17<sup>th</sup> of February. This is a chance to raise awareness and understanding about such a serious mental illness, and to challenge the stereotypes of mental illness and eating disorders.</p>
<p>
 Eating disorders often develop when food is used to cope with emotional problems, like feeling bored, unhappy, ashamed or lonely and are often triggered by stressful situations.</p>
<p>
 These are some of the more common signs of spotting eating disorders:</p>
<ol>
 <li>
  Your friend or relative may show signs of an eating disorder by behaving very differently from usual. They may appear to not want to socialize or become a recluse / withdrawn. They may also get defensive and angry at times which may feel confusing to them and you.</li>
 <li>
  They make excuses in order to not eat, and have lost a significant amount of weight, which they will not admit to when asked.</li>
 <li>
  They may see themselves as �fat� when in fact they aren�t and may be exercising a lot more than usual.</li>
 <li>
  If someone is suffering from bulimia, they may disappear soon after a meal in order to make themselves sick.</li>
</ol>
<p>
 [Please note, that these are just common signs not a formal diagnosis.]</p>
<p>
 <strong>SRSH</strong></p>
<p>
 The Union has just set up a new support group for students who are suffering or have suffered from an eating disorder. This group is run by two trained facilitators. The group will run 6pm-7pm every two week; the next session is Monday 18<sup>th</sup> February. The sessions will be held in the SU Advice centre, all sessions will be confidential. If you would like more information please email<a href="mailto:SRSH"swansea-union.co.uk@>SRSH@swansea-union.co.uk</a> for more information on SRSH click<a href="http://www.srsh.co.uk/">here</a></p>
<p>
 If you are worried you have an eating disorder please contact this confidential email address:<a href="mailto:swansea"srsh.co.uk@>swansea@srsh.co.uk</a>for more information on the SRSH group sessions or to get involved in the campaign team please email the non-confidential email address : SRSH@swansea-union.co.uk</p>
<p>
 <strong>Fundraiser</strong></p>
<p>
 Mental Wealth society is also holding a fundraiser on Wednesday to raise money for a nationwide charity called B-eat, which supports all people with eating disorders. The fundraiser is called �Sock it to Eating Disorders� and the aim is to get all of your friends, work colleagues, family and anyone you know to wear your craziest socks and donate �1 towards supporting those with eating disorders.</p>
<p>
 Watch out for them around Fulton house!</p>
<p>
 <strong>Useful Links:</strong></p>
<p>
 http://www.swansea-union.co.uk/advice/health/<br>
 <a href="http://www.srsh.co.uk/">http://www.SRSH.co.uk</a><br>
 <a href="http://www.facebook.com/groups/228528003860872/?fref=ts">http://www.facebook.com/groups/228528003860872/?fref=ts</a><br>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
	<div id="ctl00_news_rptNews_ctl15_divItem" class="item16 news_item itemEven mslorg6013 msltagleader-union">
		<div class="news_item_inner">
			<div class="news_item_hook"></div>
            <div id="ctl00_news_rptNews_ctl15_pnlOrgName" class="msl_news_org">
	
                Swansea University Students' Union
            
</div>
			<h5>Have you heard about The Student Sex WorkProject?</h5>
			<p class="msl_pubdate">Mon 11 Feb 2013</p>
			<span class="news_image"><a id="ctl00_news_rptNews_ctl15_lnkImage" href="../news/article/susu/Have-you-heard-about-The-Student-Sex-Work-Project/"><img src="/asset/News/6013/Student20Sex20Work20Project20Logo.jpg?thumbnail_width=707&amp;thumbnail_height=500&amp;resize_type=CropToFit" id="ctl00_news_rptNews_ctl15_imgImage" alt=""></a></span>
			<p class="leader">This is your chance to express your opinions on the topic.</p>
             
            

			<div id="ctl00_news_rptNews_ctl15_pnlArticleText" class="msl_newsbodytext">
	<p>
 The<strong>Student Sex Survey</strong> is now underway. Below you will find a link to The �Student Sex Survey: Attitudes and Opinions�.</p>
<p>
 <a href="https://www.surveymonkey.com/s/student_sex_survey">https://www.surveymonkey.com/s/student_sex_survey</a></p>
<p>
 This survey asks what <strong>you think</strong> about sex, sexual health and adult entertainment/sex work. The survey aims to understand the views and opinions of <strong><u>ALL</u></strong> students in Wales.</p>
<p>
 This survey is anonymous and confidential.This means that your data will be kept safe and secure and no one will be able to identify you.</p>
<p>
 On completion you can enter a prize draw to win Tesco vouchers and condoms. At the end of the questionnaire you can leave your email address to be added to our prize draw. We have 3 prizes.</p>
<p>
 <strong>Thank you for sharing with us your views, opinions and experiences.</strong></p>
<p>
 If you would like to know more about the Student Sex Work Project please go to our website: <a href="http://www.thestudentsexworkproject.co.uk/">www.thestudentsexworkproject.co.uk</a></p>
<p>
 </p>
<p>
 <strong>Ydych chi wedi clywed ynglyn �r Prosiect Myfyrwyr yn y Diwydiant Rhyw?</strong></p>
<p>
 Mae ein <strong>Harolwg Rhyw Myfyrwyr</strong> bellach wedi ei lawnsio. Mae dolen isod i�r �Arolwg Rhyw Myfyrywr: Barn ac Ymagweddiadau�</p>
<p>
 <a href="https://www.surveymonkey.com/s/Arolwg_Rhyw_Myfyrwyr">https://www.surveymonkey.com/s/Arolwg_Rhyw_Myfyrwyr</a></p>
<p>
 Mae�r arolwg hwn yn gofyn beth �rydych chi�n feddwl am ryw, iechyd rhywiol ac adloniant oedolion/gwaith rhyw. Nod yr arolwg yw dod di ddeall barn <strong><u>HOLL</u></strong> fyfyrwyr Cymru.</p>
<p>
 Mae�r arolwg hwn yn anhysbys ac yn gyfrinachol. Golyga hyn y caiff eich data ei gadw�r ddiogel ac ni fydd unrhyw un yn gallu eich hadnabod yn sg�l hyn.</p>
<p>
 Pan fyddwch wedi gorffen, gallwch gymryd rhan mewn raffl i ennill talebau Tesco a chondoms. Ar ddiwedd yr holiadur, gallwch ein darparu �ch cyfeiriad e-bost er mwyn cael eich cynnwys yn y raffl. Mae gennym 3 gwobr.</p>
<p>
 <strong>Diolch am rannu eich barn a�ch profiadau gyda ni</strong></p>
<p>
 Os hoffech wybod mwy ynglyn �r Prosiect Myfyrwyr yn y Diwydiant Rhyw, ewch i�n gwefan: <a href="http://www.thestudentsexworkproject.co.uk/">www.thestudentsexworkproject.co.uk</a></p>
<p>
 </p>
</div>

		</div>
		<div class="killfloat"></div>
	</div>
	
</div>
<div id="officerblogs" class="mslwidget" style="display: none;">
        <ul class="msl-recentblogposts">
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl01_hlPostTitle" class="msl-recentblogposttitle" href="../blogs/blog/FreshersRep/2013/03/04/Freshers-Rep/">Freshers Rep</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl01_hlBlogName" class="msl-recentblogpostblogname" href="../blogs/blog/FreshersRep/">Freshers' Rep</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl01_imgBlog" class="msl-recentblogpostimage" src="../assets/profilephotos/200x200/10733.jpg" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Mon 04 Mar 2013 11:40</span>
            <span class="msl-recentblogpost">Are you a first year in Swansea?   	Is there anything you want to find out but you don't know...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl02_hlPostTitle" class="msl-recentblogposttitle" href="../blogs/blog/EnvironmentOfficer/2013/02/28/Sustainability-Month-and-Green-Impact-Auditing-Volunteers/">Sustainability Month and Green Impact Auditing Volunteers</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl02_hlBlogName" class="msl-recentblogpostblogname" href="../blogs/blog/EnvironmentOfficer/">Environment Officer</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl02_imgBlog" class="msl-recentblogpostimage" src="../asset/Blog/12/photo.JPG?thumbnail_width=200&amp;thumbnail_height=200&amp;resize_type=ResizeWidth" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Thu 28 Feb 2013 17:46</span>
            <span class="msl-recentblogpost">Sustainability Month  	Tomorrow sees the beginning of March, which is also the start of Sustainability Month. Over the past couple...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl03_hlPostTitle" class="msl-recentblogposttitle" href="../union/officers/zahidraja/2013/02/26/Surveys-genuinely-why-wont-people-shut-up-about-them/">Surveys - genuinely, why won't people shut up about them?</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl03_hlBlogName" class="msl-recentblogpostblogname" href="../union/officers/zahidraja/">Education Officer</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl03_imgBlog" class="msl-recentblogpostimage" src="../asset/Blog/2/blog-zahid.jpg?thumbnail_width=200&amp;thumbnail_height=200&amp;resize_type=ResizeWidth" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Tue 26 Feb 2013 12:11</span>
            <span class="msl-recentblogpost">Every year at about this time, everyone who works for a University in the UK suddenly become over the top...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl04_hlPostTitle" class="msl-recentblogposttitle" href="../union/pto/BlackStudentsOfficer/2013/02/22/Help-Keep-Swansea-a-Racist-and-Fascist-Free-City-on-the-9th-March/">Help Keep Swansea a Racist and Fascist Free City on the 9th March</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl04_hlBlogName" class="msl-recentblogpostblogname" href="../union/pto/BlackStudentsOfficer/">Black Students Officer</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl04_imgBlog" class="msl-recentblogpostimage" src="../assets/profilephotos/200x200/31698.jpg" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Fri 22 Feb 2013 22:56</span>
            <span class="msl-recentblogpost">Our university is a cultural melting pot, with students from over 90 countries trusting that our university is a safe...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl05_hlPostTitle" class="msl-recentblogposttitle" href="../union/officers/zahidraja/2013/02/21/Union-to-launch-campaign-on-Feedback-Exam-Results/">Union to launch three stage campaign on Feedback / Exam Results</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl05_hlBlogName" class="msl-recentblogpostblogname" href="../union/officers/zahidraja/">Education Officer</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl05_imgBlog" class="msl-recentblogpostimage" src="../asset/Blog/2/blog-zahid.jpg?thumbnail_width=200&amp;thumbnail_height=200&amp;resize_type=ResizeWidth" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Thu 21 Feb 2013 13:30</span>
            <span class="msl-recentblogpost">At the start of this month, the Students' Union held its first series of College Subject Rep forums. One of...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl06_hlPostTitle" class="msl-recentblogposttitle" href="../union/officers/tomupton/2013/02/19/Light-Up-The-Darkness-In-The-Park/">Light Up The Darkness (In The Park!)</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl06_hlBlogName" class="msl-recentblogpostblogname" href="../union/officers/tomupton/">President</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl06_imgBlog" class="msl-recentblogpostimage" src="../asset/Blog/3/tom.jpg?thumbnail_width=200&amp;thumbnail_height=200&amp;resize_type=ResizeWidth" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Tue 19 Feb 2013 15:14</span>
            <span class="msl-recentblogpost">Monday was supposed to be a pretty exciting day for the SU. &nbsp; After 20 years of campaigning by Students' Union...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl07_hlPostTitle" class="msl-recentblogposttitle" href="../blogs/blog/LGBT/2013/02/19/LGBT-History-Month-Day-Two/">LGBT History Month: Day Two!</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl07_hlBlogName" class="msl-recentblogpostblogname" href="../blogs/blog/LGBT/">LGBT+</a>
            <span class="msl-recentblogpostdate">Tue 19 Feb 2013 15:12</span>
            <span class="msl-recentblogpost">So our 'pop up' stall has popped up again on campus, today saw us in the refectory spreading awareness and...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl08_hlPostTitle" class="msl-recentblogposttitle" href="../union/officers/zahidraja/2013/02/19/SWANSEA-STUDENTS-want-to-be-discovered-by-graduate-recruiters-Find-out-how/">SWANSEA STUDENTS: want to be discovered by graduate recruiters? Find out how!</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl08_hlBlogName" class="msl-recentblogpostblogname" href="../union/officers/zahidraja/">Education Officer</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl08_imgBlog" class="msl-recentblogpostimage" src="../asset/Blog/2/blog-zahid.jpg?thumbnail_width=200&amp;thumbnail_height=200&amp;resize_type=ResizeWidth" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Tue 19 Feb 2013 13:12</span>
            <span class="msl-recentblogpost">Important info about getting discovered by graduate recruiters AND how the recognition of extracurricular activities is changing in the UK...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl09_hlPostTitle" class="msl-recentblogposttitle" href="../union/officers/tomupton/2013/02/18/AGM-Postponed-Forum-still-on/">AGM Postponed, Forum still on!</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl09_hlBlogName" class="msl-recentblogpostblogname" href="../union/officers/tomupton/">President</a>
            <img id="ctl00_officerblogs_rptRecentBlogPosts_ctl09_imgBlog" class="msl-recentblogpostimage" src="../asset/Blog/3/tom.jpg?thumbnail_width=200&amp;thumbnail_height=200&amp;resize_type=ResizeWidth" alt="" style="border-width:0px;">
            <span class="msl-recentblogpostdate">Mon 18 Feb 2013 16:55</span>
            <span class="msl-recentblogpost">Dear all, I would like to personally apologise for tonight's AGM being postponed. &nbsp;Unfortunately, something which usually happens like...</span>
        </li>
        <li class="msl-recentblogpost">
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl10_hlPostTitle" class="msl-recentblogposttitle" href="../blogs/blog/LGBT/2013/02/18/LGBT-History-Month-Day-One/">LGBT History Month: Day One!</a>
            <a id="ctl00_officerblogs_rptRecentBlogPosts_ctl10_hlBlogName" class="msl-recentblogpostblogname" href="../blogs/blog/LGBT/">LGBT+</a>
            <span class="msl-recentblogpostdate">Mon 18 Feb 2013 14:30</span>
            <span class="msl-recentblogpost">This morning saw the beginning of our two week long campaign in celebration of LGBT History Month!   	For the beginning...</span>
        </li>
        </ul>
</div>
<!--
FEATURED EVENTS
-->
<div id="eventsfeatured" class="mslwidget" style="display: none;">

<div class="msl_eventlist">
            <div>
                        <div class="event_item item1 itemOdd msl-brand-summerball" data-msl-organisation-id="6042">

			                <dl>
				                <dt>
                                    <a href="../ents/event/497/"><span class="msl_event_image"><img src="/asset/Event/6042/mainmsl.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Entertainments</span>
                                    <a href="/ents/event/497/" class="msl_event_name">Summer Ball 2013 #SSB13</a>
                                </dt>
                                <dd class="msl_event_time">3rd June 4pm - 11:59pm</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description"></dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/497/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">summerball</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
						                 | 
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
						                 | 
                                            <a href="/ents/eventlist/societies/">Societies</a>
						                 | 
                                            <a href="/ents/eventlist/union/">Union Events</a>
						                 | 
                                            <a href="/ents/eventlist/specialevents/">Special Event</a>
						                 | 
                                            <a href="/ents/eventlist/freshers/">Fresher Events</a>
						                 | 
                                            <a href="/ents/eventlist/partypacks/">Party Packages</a>
						                 | 
                                            <a href="/ents/eventlist/summerball/">Summer Ball</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item2 itemEven msl-brand-summerball" data-msl-organisation-id="6042">

			                <dl>
				                <dt>
                                    <a href="../ents/event/501/"><span class="msl_event_image"><img src="/asset/Event/6042/summergrad.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Entertainments</span>
                                    <a href="/ents/event/501/" class="msl_event_name">Summer and Graduation Combo</a>
                                </dt>
                                <dd class="msl_event_time">3rd June 4:01pm - 11:59pm</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description">Graduation Combination Discount</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/501/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">summerball</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
						                 | 
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
						                 | 
                                            <a href="/ents/eventlist/societies/">Societies</a>
						                 | 
                                            <a href="/ents/eventlist/specialevents/">Special Event</a>
						                 | 
                                            <a href="/ents/eventlist/summerball/">Summer Ball</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item15 itemOdd msl-brand-gigslivemusic" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/534/"><span class="msl_event_image"><img src="/asset/Event/6050/kingsfoil_poster.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/534/" class="msl_event_name">Kingsfoil | Featuring Frankie Muniz</a>
                                </dt>
                                <dd class="msl_event_time">30th May 7:30pm - 11pm</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description">Kingsfoil take to the Sin City stage - featuring Frankie Muniz of Malcom in the Middle fame.</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/534/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">gigslivemusic</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item15 itemOdd msl-brand-gigslivemusic" data-msl-organisation-id="6050">

			                <dl>
				                <dt>
                                    <a href="../ents/event/534/"><span class="msl_event_image"><img src="/asset/Event/6050/kingsfoil_poster.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Sin City</span>
                                    <a href="/ents/event/534/" class="msl_event_name">Kingsfoil | Featuring Frankie Muniz</a>
                                </dt>
                                <dd class="msl_event_time">30th May 7:30pm - 11pm</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description">Kingsfoil take to the Sin City stage - featuring Frankie Muniz of Malcom in the Middle fame.</dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/534/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand">gigslivemusic</dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
                        <div class="event_item item3 itemOdd" data-msl-organisation-id="6042">

			                <dl>
				                <dt>
                                    <a href="../ents/event/521/"><span class="msl_event_image"><img src="/asset/Event/6042/gradball13_couple_a3.jpg?thumbnail_width=480&amp;thumbnail_height=339&amp;resize_type=CropToFit" alt=""></span></a>
                                    <span class="msl_event_organisation">Entertainments</span>
                                    <a href="/ents/event/521/" class="msl_event_name">Graduation Ball</a>
                                </dt>
                                <dd class="msl_event_time">10th July 8pm - 1am</dd>
                                <dd class="msl_event_location"></dd>

				                <dd class="msl_event_description"></dd>

				                <dd class="msl_event_tickets">
                                    <a class="msl_ticket" href="/ents/event/521/">Buy Tickets</a>
                                </dd>

                                <dd class="msl_event_brand"></dd>

				                <dd class="msl_event_types">
                                            <a href="/ents/eventlist/livemusic/">Live Music</a>
						                 | 
                                            <a href="/ents/eventlist/clubnights/">Club Nights</a>
						                 | 
                                            <a href="/ents/eventlist/societies/">Societies</a>
						                 | 
                                            <a href="/ents/eventlist/specialevents/">Special Event</a>
						                 | 
                                            <a href="/ents/eventlist/summerball/">Summer Ball</a>
				                </dd>

				                <dd class="msl_event_hook">

			                </dd></dl>

                        </div>
</div>
</div>

</div>

<!-- Member List -->

<div id="su-data-memberlist-pto" class="mslwidget" style="display: none;">

<div class="msl-groupedmemberlist">
    
    
            

                

                        <h4>Black Student Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl00$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_hdnPersonID" value="31698">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_lnkImage" href="../profile/31698/"><img src="/assets/profilephotos/80x100/31698.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_lnkName" href="../profile/31698/">Keryn Jalli</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:kerynjalli92"yahoo.co.uk@>kerynjalli92@yahoo.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Environment Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl01$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_hdnPersonID" value="10425">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10425/"><img src="/assets/profilephotos/80x100/10425.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_lnkName" href="../profile/10425/">Simon Wilde</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:643473"swansea.ac.uk@>643473@swansea.ac.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Ethics Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl02$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_hdnPersonID" value="15831">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_lnkImage" href="../profile/15831/"><img src="/assets/profilephotos/80x100/15831.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_lnkName" href="../profile/15831/">Robert Abrams</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:doogleohyeah"hotmail.com@>doogleohyeah@hotmail.com</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Freshers' Representative Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl03$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_hdnPersonID" value="10733">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10733/"><img src="/assets/profilephotos/80x100/10733.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_lnkName" href="../profile/10733/">Robiu Salisu</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:Robiu_salisu"hotmail.co.uk@>Robiu_salisu@hotmail.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>General Secretary</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl04$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_hdnPersonID" value="10521">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10521/"><img src="/assets/profilephotos/80x100/nophoto.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_lnkName" href="../profile/10521/">Ruth Oldham</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:646652"swansea.ac.uk@>646652@swansea.ac.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>LGBT+ Officer (Open Place)</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl05$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_hdnPersonID" value="16914">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_lnkImage" href="../profile/16914/"><img src="/assets/profilephotos/80x100/nophoto.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_lnkName" href="../profile/16914/">Philip McNamee</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:philmcnamee"hotmail.com@>philmcnamee@hotmail.com</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>LGBT+ Officer (Women's)</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl06$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_hdnPersonID" value="32978">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_lnkImage" href="../profile/32978/"><img src="/assets/profilephotos/80x100/nophoto.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_lnkName" href="../profile/32978/">Rachel Hodgson</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:r3d"live.co.uk@>r3d@live.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Mature Stduents' Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl07$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_hdnPersonID" value="10508">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10508/"><img src="/assets/profilephotos/80x100/10508.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_lnkName" href="../profile/10508/">Matthew Johnson</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl07_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:663957"swansea.ac.uk@>663957@swansea.ac.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Postgraduates' Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl08$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_hdnPersonID" value="11429">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_lnkImage" href="../profile/11429/"><img src="/assets/profilephotos/80x100/11429.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_lnkName" href="../profile/11429/">Charlotte Davies</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl08_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:533748"swansea.ac.uk@>533748@swansea.ac.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Student with Disabilities Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl09$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_hdnPersonID" value="31741">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_lnkImage" href="../profile/31741/"><img src="/assets/profilephotos/80x100/nophoto.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_lnkName" href="../profile/31741/">Victoria Baker</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl09_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:toffie2003"msn.com@>toffie2003@msn.com</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Students With Caring Responsibilities Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl10$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_hdnPersonID" value="32633">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_lnkImage" href="../profile/32633/"><img src="/assets/profilephotos/80x100/nophoto.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_lnkName" href="../profile/32633/">Laura McKeever</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl10_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:ljmckeever"live.co.uk@>ljmckeever@live.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                 
                 

        
</div>

</div>

<div id="su-data-memberlist-fto" class="mslwidget" style="display: none;">

<div class="msl-groupedmemberlist">
    
    
            

                

                        <h4>Education Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl00$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_hdnPersonID" value="10010">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10010/"><img src="/assets/profilephotos/80x100/10010.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_lnkName" href="../profile/10010/">Zahid Raja</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl00_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:educationofficer"swansea-union.co.uk@>educationofficer@swansea-union.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>International Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl01$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_hdnPersonID" value="10021">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10021/"><img src="/assets/profilephotos/80x100/nophoto.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_lnkName" href="../profile/10021/">Mahaboob Basha V.r.s.a.</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl01_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:international"swansea-union.co.uk@>international@swansea-union.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>President</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl02$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_hdnPersonID" value="10023">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10023/"><img src="/assets/profilephotos/80x100/nophoto.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_lnkName" href="../profile/10023/">Tom Upton</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl02_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:president"swansea-union.co.uk@>president@swansea-union.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Societies and Services Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl03$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_hdnPersonID" value="10013">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10013/"><img src="/assets/profilephotos/80x100/10013.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_lnkName" href="../profile/10013/">Josh Hayman</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl03_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:societiesandservices"swansea-union.co.uk@>societiesandservices@swansea-union.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Sports Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl04$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_hdnPersonID" value="10022">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10022/"><img src="/assets/profilephotos/80x100/10022.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_lnkName" href="../profile/10022/">Imogen Stanley</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl04_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:Sportsofficer"swansea-union.co.uk@>Sportsofficer@swansea-union.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Welfare Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl05$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_hdnPersonID" value="10020">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10020/"><img src="/assets/profilephotos/80x100/10020.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_lnkName" href="../profile/10020/">Charlotte Britton</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl05_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:welfareofficer"swansea-union.co.uk@>welfareofficer@swansea-union.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                        <h4>Womens Officer</h4>
                        <ul>
                                <li>
                                    
                                    <div id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_pnlBadge" class="badge clearfix">
	
<input type="hidden" name="ctl00$gmlFTO$rptGroups$ctl00$rptGroupsItemised$ctl06$rptMembers$ctl01$bPerson$hdnPersonID" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_hdnPersonID" value="10025">

	<div class="badge_tools">

		<a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_lnkImage" href="../profile/10025/"><img src="/assets/profilephotos/80x100/10025.jpg" id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_imgAvatar" class="badge_avatar"></a>
		
		<ul>
		    <li id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_liDeleteFriend"></li>
			
			
			
			
		</ul>
		
	</div>
	
	<dl>
		<dt><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_lnkName" href="../profile/10025/">Becki Warrillow</a></dt>
		
		
		
		<dd id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_dtEmailAddress"><a id="ctl00_gmlFTO_rptGroups_ctl00_rptGroupsItemised_ctl06_rptMembers_ctl01_bPerson_hlEmailAddress" href="mailto:womensofficer"swansea-union.co.uk@>womensofficer@swansea-union.co.uk</a></dd>
		
				
		
		
		
		
	</dl>
	
	<div class="killfloat">&nbsp;</div>

</div>
                                </li>
                            </ul>

                    

                 
                 

        
</div>

</div>