<?php if(!class_exists('raintpl')){exit;}?><div class="login-gueststaff">
	<div class="mslwidget">
		<div class="sidepanel">
			<div id="ctl00_ctl11_pnlStandardLogin" class="login" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ctl11_btnLogin')">
				<label for="ctl00_ctl11_UserName" id="ctl00_ctl11_lblUserName">Username</label>
				<input name="ctl00$ctl11$UserName" type="text" id="ctl00_ctl11_UserName" class="textbox">
				<label for="ctl00_ctl11_Password" id="ctl00_ctl11_lblPassword">Password</label>
				<input name="ctl00$ctl11$Password" type="password" id="ctl00_ctl11_Password" class="textbox">
				<input type="submit" name="ctl00$ctl11$btnLogin" value="Login" id="ctl00_ctl11_btnLogin" class="button">
		</div>		
			<div class="login">
				<a id="ctl00_ctl11_lnkForgottenPassword" href="/account/resetpassword/">Forgotten Password</a>
			</div>
		</div>
	</div>

	<div class="register">
		<div class="login-notice">
			<!--<p>If you are a guest or a member of Union Staff <span style="text-decoration:underline">and do not already have an account</span>, register below:</p>-->
		</div>
		<ul class="msl_list">
			<a href="/account/register/staff"><div class="login-button m-btn purple new-staff">New Registration</div></a>
			<a href="/account/register/guest"><div class="login-button m-btn purple new-guest">New Registration</div></a>
		</ul>
	</div>
</div>