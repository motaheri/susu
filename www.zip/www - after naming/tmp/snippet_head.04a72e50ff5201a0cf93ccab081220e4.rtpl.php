<?php if(!class_exists('raintpl')){exit;}?>
        <!--[if lt IE 9]><script src="http://cdn.jsdelivr.net/html5shiv/3.6.1/html5shiv.min.js"></script><![endif]-->
		
        <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/normalize/2.0.1/normalize.css" />
		
		<link rel="stylesheet" href="media/css/dcsns_light.css" />
        <link rel="stylesheet" href="css/su_menufication.min.css" />
        <link rel="stylesheet" href="css/su_fonts.css" />
        <link rel="stylesheet" href="css/su_layout.css" />
        <link rel="stylesheet" href="css/su_snippet_news.css" />
        <link rel="stylesheet" href="css/su_snippet_events.css" />
        <link rel="stylesheet" href="css/su_snippet_blogs.css" />
        <link rel="stylesheet" href="css/su_lightbox.css" />
        <link rel="stylesheet" href="css/su_snippet_coverflow.css" />
        <link rel="stylesheet" href="css/su_snippet_menu.css" />
        <link rel="stylesheet" href="css/su_template_activities.css" />
        <link rel="stylesheet" href="css/su_snippet_media.css" />
        <link rel="stylesheet" href="css/su_union-officers.css" />
		<link rel="stylesheet" href="css/su_snippet_advert.css" />
		<link rel="stylesheet" href="css/su_snippet_footer.css" />